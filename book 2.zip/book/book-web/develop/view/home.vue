<style>
    
</style>

<template>
    <section class="page-alert" v-show="alert.show">
        <Alert :show.sync="alert.show" :type.sync="alert.type">
            {{ alert.message }}
        </Alert>
    </section>
    <div class="">
        <div class="home-left relative">
            <div class="hl-cwrap">
                <div v-if="myList.length>0" class="hl-card" v-for="item in myList">
                    <div class="hl-card-name">
                        {{item.book_name}}
                    </div>
                    <div class="hl-card-count color-a">
                        {{item.count}}
                    </div>
                    <div class="hl-card-time">
                        {{item.create_at | date}}
                    </div>
                </div>
                <div v-if="myList.length==0" class="hl-card">
                    <span class="hl-tip">还未借书</span>
                </div>
            </div>
        </div>
        <div class="home-right">
            <div class="home-card">
                <div class="hc-title">最新书籍</div>
                <div class="hc-body">
                    <ul>
                        <li v-for="item in newBookList">{{item.name}}</li>
                    </ul>
                </div>
            </div>
            <div class="home-card">
                <div class="hc-title">借阅排行榜</div>
                <div class="hc-body">
                    <ul>
                        <li v-for="item in rankingList">{{item._id}}</li>
                    </ul>
                </div>
            </div>
            <div class="home-card">
                <div class="hc-title">借书达人</div>
                <div class="hc-body">
                    <ul>
                        <li v-for="item in dresserList">{{item._id}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    var Alert = require('../components/alert.vue');
    module.exports =  {
        components: {
            Alert
        },
        data (){
            return {
                alert: {
                    show: false,
                    type: 'danger',
                    message: '' 
                },
                submitObj: {
                    name: '',
                    password: ''
                },
                rankingList: [],
                dresserList: [],
                newBookList: [],
                myList: []
            }
        },
        events: {
           
        },
        ready (){
            this.getRanking();
            this.getDresser();
            this.getNewBook();
            this.getMyList();
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },

            // 显示提示框
            showAlert (type, message){
                this.$root.showAlert(this, type, message);
            },
            // 排行榜
            getRanking(){
                var that = this;
                this.ajax({
                    type: 'get',
                    url: '/api/history/ranking',
                    success (result){
                        that.rankingList = result.data;
                    },
                    error (err){}
                });
            },
            // 借书达人
            getDresser(){
                var that = this;
                this.ajax({
                    type: 'get',
                    url: '/api/history/dresser',
                    success (result){
                        that.dresserList = result.data;
                    },
                    error (err){}
                });
            },

            // 最新书
            getNewBook(){
                var that = this;
                var obj = {
                    page: 1,
                    per_page: 6
                }
                this.ajax({
                    type: 'post',
                    data: obj,
                    url: '/api/book/list',
                    success (result){
                        that.newBookList = result.data.list;
                    },
                    error (err){}
                });
            },

            // 我借的书
            getMyList (){
                var that = this;
                var obj = {
                    page: 1,
                    per_page: 9999,
                    user_id: localStorage.ksc_user_id
                }
                
                this.ajax({
                    type: 'post',
                    data: obj,
                    url: '/api/borrow/list',
                    success (result){
                        that.myList = result.data.list;
                        
                    },
                    error (err){}
                });
            },
        }
    }
</script>