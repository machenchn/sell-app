<style>
    
</style>

<template>
    <section class="page-alert" v-show="alert.show">
        <Alert :show.sync="alert.show" :type.sync="alert.type">
            {{ alert.message }}
        </Alert>
    </section>
    <div class="ks-tab pb">
        <div class="tab-body">
            <div class="search-area">
                <div class="srh-cl clearfix">
                    <div class="srh-item">
                        <label class="srh-item-l">姓名：</label>
                        <div class="srh-item-r">
                            <input type="text" 
                                v-model="srhParam.name"
                                @keyup="keyupSearch($event)"
                                placeholder="姓名" 
                                class="text">
                        </div>
                    </div>
                    <button class="btn btn-primary btn-srh" @click="doSearch()">查询</button>
                    <button v-if="role<3" class="btn btn-primary-line btn-srh pull-right" @click="add()">添加</button>
                    <a v-if="role<3" download class="btn btn-primary-line btn-srh pull-right" href="/api/user/exports">导出</a>
                </div>
            </div>
            <div class="content-area">
                <div class="table-area">
                    <div class="table-wrap">
                        <table class="ks-table">
                            <thead>
                                <tr>
                                    <th nowrap>账号</th>
                                    <th nowrap>权限</th>
                                    <th nowrap>姓名</th>
                                    <th nowrap>手机</th>
                                    <th nowrap>邮箱</th>
                                    <th nowrap>创建时间</th>
                                    <th nowrap v-if="role<3">操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in listData.lists">
                                    <td>{{item.acount}}</td>
                                    <td>{{item.auth | init_data_filter 'auth'}}</td>
                                    <td>{{item.name}}</td>
                                    <td>{{item.tell}}</td>
                                    <td>{{item.email}}</td>
                                    <td>{{item.create_at | date}}</td>
                                    <td v-if="role<3">
                                        <a v-if="item.auth>2 || (item.auth==2 && role==1)" @click="del(item._id)" class="color-c">删除</a>
                                        <a v-if="item.auth>2 || (item.auth==2 && role==1)" @click="edit(item)">编辑</a>
                                        <a v-if="item.auth>2 || (item.auth==2 && role==1)"
                                            @click="resetPassword(item._id)">重置密码</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-area">
                        <Pagination 
                            :total-row="pagination.totalRow"
                            :page-size="pagination.per_page" 
                            :index="pagination.page" 
                            max-length="pagination.maxLength"
                            page-event="refreshPage"></Pagination>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <Dialog :show.sync="editFlag" :title="editTitle" btn='edit' button="确定" classname="dialog-type-a">
        <div class="interval-content">
            <div class="">
                <div class="cl" v-if="role==1">
                    <label class="cl-l">角色：</label>
                    <div class="cl-r">
                        <div class="ks-dropdown mar-l0 bs-input-width" 
                            v-ks-select="submitObj.auth"
                            :options="roleArray" 
                            ></div>
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">登录账号：</label>
                    <div class="cl-r">
                        <input type="text" :disabled="isEdit" class="text bs-input-width" v-model="submitObj.acount">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">姓名：</label>
                    <div class="cl-r">
                        <input type="text" class="text bs-input-width" v-model="submitObj.name">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">手机：</label>
                    <div class="cl-r">
                        <input type="text" class="text bs-input-width" v-model="submitObj.tell">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">邮箱：</label>
                    <div class="cl-r">
                        <input type="text" class="text bs-input-width" v-model="submitObj.email">
                    </div>
                </div>
                <div v-if="!isEdit" class="cl">
                    <label class="cl-l">密码：</label>
                    <div class="cl-r">
                        <div class="ut">默认密码为“111111”</div>
                    </div>
                </div>
            </div>
        </div>
    </Dialog>
</template>

<script>
    var Alert = require('../components/alert.vue');
    var Pagination = require('../components/pagination.vue');
    var Dialog = require('../components/dialog.vue');
    module.exports =  {
        components: {
            Alert,
            Pagination,
            Dialog
        },
        data (){
            return {
                alert: {
                    show: false,
                    type: 'danger',
                    message: '' 
                },
                pagination: {
                    page: 1,
                    per_page: 10,
                    totalRow: 0,
                    maxLength: 5
                },
                listData: {
                    total: '',
                    lists:[]
                },
                isEdit: false,
                editFlag: false,
                editTitle: '',
                srhParam: {},
                submitObj: {
                    id:'',
                    name: '',
                    auth: 9,
                    password:'',
                    profession: ''
                },
                role: localStorage.ksc_auth,
                roleArray: {
                    2: '管理员',
                    9: '普通用户'
                }
            }
        },
        events: {
           'refreshPage': function (data) {
                this.pagination.page = data.index;
                this.pagination.per_page = parseInt(data.pageSize);
                this.getData();
            },
            // 编辑新建
            'on-edit-close' :function(){
                this.editFlag = false;
            },
            'on-edit-ok': function(){
                // this.selectFlag();
                this.editSubmit();
            },
        },
        ready (){
            this.getData();
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },

            // 显示提示框
            showAlert (type, message){
                this.$root.showAlert(this, type, message);
            },
            
            // 获取数据
            getData (){
                var that = this;
                this.srhParam.page = this.pagination.page;
                this.srhParam.per_page = this.pagination.per_page;
                this.ajax({
                    type: 'post',
                    data: this.srhParam,
                    url: '/api/user/list',
                    success (result){
                        that.listData.lists = result.data.list;
                        that.pagination.totalRow = result.data.total;
                    },
                    error (err){}
                });
            },
            // 查询按钮
            doSearch(){
                this.pagination.page = 1;
                this.getData();
            },
            // keyup触发搜索
            keyupSearch (event){
                if(event.keyCode == 13){
                    this.doSearch();
                }
            },
            // 查询单个用户
            getUser (id){
                var that = this;
                this.ajax({
                    type: 'get',
                    url: '/api/user/detail/' + id,
                    success (result){
                        that.currentItem = result.data;
                    },
                    error (err){}
                });
            },
             // 添加编辑
            add(){
                this.isEdit = false;
                this.editTitle = "添加";
                this.clearSubmitObj();
                this.submitObj.id = new Date().getTime();
                this.editFlag = true;
            },
            edit (item){
                this.isEdit = true;
                this.editTitle = "编辑";
                this.submitObj.id = item._id;
                this.submitObj = $.extend({},item);
                this.editFlag = true;
            },
            editSubmit(){
                var that = this;
                var url;
                if(this.isEdit) {
                    this.submitObj.id = this.submitObj._id;
                    url = '/api/user/update/';
                } else {
                    url = '/api/user/add';
                }
                this.ajax({
                    type: 'post',
                    data: this.$root.trim(this.submitObj),
                    url: url,
                    success (result){
                        if(that.isEdit) {
                            that.getData();
                        } else {
                           that.doSearch();
                        }
                        that.editFlag = false;
                    },
                    error (err){}
                });
            },
            del(id) {
                var that = this;
                this.$root.tipSure({
                    scope: this,
                    sure: function(){
                        this.ajax({
                            type: 'post',
                            url: '/api/user/remove',
                            data: {id: id},
                            success: function(rel){
                                that.doSearch();
                            }
                        });
                    }
                });
            },
            clearSubmitObj(){
                this.submitObj = {
                    id:'',
                    name: '',
                    auth: 9,
                    password:'',
                    profession: ''
                };
            },
            //重置密码
            resetPassword(id){
                var that = this;
                this.$root.tipSure({
                    scope: this,
                    info: '重置密码后为“111111”',
                    sure: function(){
                        this.ajax({
                            type: 'post',
                            data: {id: id},
                            url: '/api/user/reset/',
                            success: function(rel){
                                that.showAlert('success','操作成功');
                            }
                        });
                    }
                });
            }

        }
    }
</script>