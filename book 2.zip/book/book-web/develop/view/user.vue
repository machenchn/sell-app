<style>
    
</style>

<template>
    <section class="page-alert" v-show="alert.show">
        <Alert :show.sync="alert.show" :type.sync="alert.type">
            {{ alert.message }}
        </Alert>
    </section>
    <div class="">
        <div class="home-left relative">
            <div class="user-info">
                <div class="cl">
                    <label for="" class="cl-l">账号：</label>
                    <div class="cl-r">{{dataObj.acount}}</div>
                </div>
                <div class="cl">
                    <label for="" class="cl-l">姓名：</label>
                    <div class="cl-r">{{dataObj.name}}</div>
                </div>
                <div class="cl">
                    <label for="" class="cl-l">权限：</label>
                    <div class="cl-r">{{dataObj.auth | init_data_filter 'auth'}}</div>
                </div>
                <div class="cl">
                    <label for="" class="cl-l">手机：</label>
                    <div class="cl-r">{{dataObj.tell}}</div>
                </div>
                <div class="cl">
                    <label for="" class="cl-l">邮箱：</label>
                    <div class="cl-r">{{dataObj.email}}</div>
                </div>
                <div class="cl">
                    <label for="" class="cl-l">创建时间：</label>
                    <div class="cl-r">{{dataObj.create_at | datetime}}</div>
                </div>
                <div class="cl mar-td">
                    <label for="" class="cl-l"></label>
                    <div class="cl-r">
                        <button class="btn btn-primary" @click="edit()">修改密码</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="home-right">
            <div class="home-card">
                <div class="hc-title">最新书籍</div>
                <div class="hc-body">
                    <ul>
                        <li v-for="item in newBookList">{{item.name}}</li>
                    </ul>
                </div>
            </div>
            <div class="home-card">
                <div class="hc-title">借阅排行榜</div>
                <div class="hc-body">
                    <ul>
                        <li v-for="item in rankingList">{{item._id}}</li>
                    </ul>
                </div>
            </div>
            <div class="home-card">
                <div class="hc-title">借书达人</div>
                <div class="hc-body">
                    <ul>
                        <li v-for="item in dresserList">{{item._id}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <Dialog :show.sync="editFlag" title="修改密码" btn='edit' button="确定" classname="dialog-type-a">
        <div class="interval-content">
            <div class="">
                <div class="cl">
                    <label class="cl-l">新密码：</label>
                    <div class="cl-r">
                        <input type="password" class="text bs-input-width" v-model="submitObj.password">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">再次输入：</label>
                    <div class="cl-r">
                        <input type="password" class="text bs-input-width" v-model="submitObj.rePassword">
                    </div>
                </div>
            </div>
        </div>
    </Dialog>
</template>

<script>
    var Alert = require('../components/alert.vue');
    var Dialog = require('../components/dialog.vue');
    module.exports =  {
        components: {
            Alert,
            Dialog
        },
        data (){
            return {
                alert: {
                    show: false,
                    type: 'danger',
                    message: '' 
                },
                dataObj:{
                    acount: localStorage.ksc_acount,
                    name: localStorage.ksc_name,
                    auth: localStorage.ksc_auth,
                    tell: localStorage.ksc_tell,
                    email: localStorage.ksc_email,
                    create_at: localStorage.ksc_create_at,
                },
                submitObj: {
                    password: '',
                    rePassword: '',
                    id: localStorage.ksc_user_id
                },
                rankingList: [],
                dresserList: [],
                newBookList: [],
                editFlag: false,
                role:localStorage.ksc_auth
            }
        },
        events: {
           // 修改密码
            'on-edit-close' :function(){
                this.editFlag = false;
            },
            'on-edit-ok': function(){
                // this.selectFlag();
                this.editSubmit();
            },
        },
        ready (){
            this.getRanking();
            this.getDresser();
            this.getNewBook();
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },

            // 显示提示框
            showAlert (type, message){
                this.$root.showAlert(this, type, message);
            },
            // 排行榜
            getRanking(){
                var that = this;
                this.ajax({
                    type: 'get',
                    url: '/api/history/ranking',
                    success (result){
                        that.rankingList = result.data;
                    },
                    error (err){}
                });
            },
            // 借书达人
            getDresser(){
                var that = this;
                this.ajax({
                    type: 'get',
                    url: '/api/history/dresser',
                    success (result){
                        that.dresserList = result.data;
                    },
                    error (err){}
                });
            },

            // 最新书
            getNewBook(){
                var that = this;
                var obj = {
                    page: 1,
                    per_page: 6
                }
                this.ajax({
                    type: 'post',
                    data: obj,
                    url: '/api/book/list',
                    success (result){
                        that.newBookList = result.data.list;
                    },
                    error (err){}
                });
            },
            // 修改密码
            edit (item){
                this.editFlag = true;
            },
            editSubmit(){
                var that = this;
                if (!this.submitObj.password || !this.submitObj.rePassword) {
                    return false
                } else if (this.submitObj.password!=this.submitObj.rePassword) {
                    this.showAlert('danger', '两次输入密码不一至');
                    return false;
                } 
                this.ajax({
                    type: 'post',
                    data: this.$root.trim(this.submitObj),
                    url: '/api/user/update_password',
                    success (result){
                        that.editFlag = false;
                    },
                    error (err){}
                });
            },
        }
    }
</script>