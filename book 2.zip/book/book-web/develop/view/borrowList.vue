<style>
    
</style>

<template>
    <section class="page-alert" v-show="alert.show">
        <Alert :show.sync="alert.show" :type.sync="alert.type">
            {{ alert.message }}
        </Alert>
    </section>
    <div class="ks-tab pb">
        <div class="tab-body">
            <div class="search-area">
                <div class="srh-cl clearfix">
                    <div class="srh-item">
                        <label class="srh-item-l">书名：</label>
                        <div class="srh-item-r">
                            <input type="text" 
                                v-model="srhParam.book_name"
                                @keyup="keyupSearch($event)"
                                placeholder="书名" 
                                class="text">
                        </div>
                    </div>
                    <div class="srh-item srh-item-select2">
                        <label class="srh-item-l">用户：</label>
                        <div class="srh-item-r clearfix">
                            <Select2 placeholder="请选择用户" 
                                :lists="userList"
                                :value.sync="srhParam.user_id"
                                show-select="全部"
                                class="select2-width"></Select2>
                        </div>
                    </div>
                    <button class="btn btn-primary btn-srh" @click="doSearch()">查询</button>
                    <a v-if="role<3" download class="btn btn-primary-line btn-srh pull-right" href="/api/borrow/exports">导出</a>
                </div>
            </div>
            <div class="content-area">
                <div class="table-area">
                    <div class="table-wrap">
                        <table class="ks-table">
                            <thead>
                                <tr>
                                    <th width="20%">用户</th>
                                    <th width="30%">书名</th>
                                    <th width="15%">数量</th>
                                    <th width="20%">开始借阅时间</th>
                                    <th width="15%" v-if="role<3">操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in listData.lists">
                                    <td>{{item.user_name}}</td>
                                    <td>{{item.book_name}}</td>
                                    <td>{{item.count}}</td>
                                    <td>{{item.create_at | datetime}}</td>
                                    <td v-if="role<3">
                                        <a @click="back(item)">归还</a>
                                        <a @click="reBorrow(item)">续借</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-area">
                        <Pagination 
                            :total-row="pagination.totalRow"
                            :page-size="pagination.per_page" 
                            :index="pagination.page" 
                            max-length="pagination.maxLength"
                            page-event="refreshPage"></Pagination>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    var Alert = require('../components/alert.vue');
    var Pagination = require('../components/pagination.vue');
    var Dialog = require('../components/dialog.vue');
    var Select2 = require('../components/select2.vue');
    module.exports =  {
        components: {
            Alert,
            Pagination,
            Dialog,
            Select2
        },
        data (){
            return {
                alert: {
                    show: false,
                    type: 'danger',
                    message: '' 
                },
                pagination: {
                    page: 1,
                    per_page: 10,
                    totalRow: 0,
                    maxLength: 5
                },
                listData: {
                    total: '',
                    lists:[]
                },
                currentItem: '',
                srhParam: {
                    user_id: '',
                    book_name: '',
                },
                userList: '',
                role: localStorage.ksc_auth,
            }
        },
        events: {
           'refreshPage': function (data) {
                this.pagination.page = data.index;
                this.pagination.per_page = parseInt(data.pageSize);
                this.getData();
            },
        },
        ready (){
            this.getData();
            if(this.role < 3) {
                this.getUserList();
            }
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },

            // 显示提示框
            showAlert (type, message){
                this.$root.showAlert(this, type, message);
            },

            // 获取数据
            getData (){
                var that = this;
                this.srhParam.page = this.pagination.page;
                this.srhParam.per_page = this.pagination.per_page;
                this.ajax({
                    type: 'post',
                    data: this.srhParam,
                    url: '/api/borrow/list',
                    success (result){
                        that.listData.lists = result.data.list;
                        that.pagination.totalRow = result.data.total;
                    },
                    error (err){}
                });
            },
            // 查询按钮
            doSearch(){
                this.pagination.page = 1;
                this.getData();
            },
            // keyup触发搜索
            keyupSearch (event){
                if(event.keyCode == 13){
                    this.doSearch();
                }
            },

            // 查询全部用户列表
            getUserList(){
                var that = this;
                this.ajax({
                    type: 'post',
                    data: this.srhParam,
                    url: '/api/user/list_all',
                    success (result){
                        // that.books.lists = result.data.list;
                        // that.pagination.totalRow = result.data.total;
                        that.userList = result.data;
                    },
                    error (err){}
                });
            },

            // 归还
            back(item){
                var that = this;
                var obj = {
                    id: item._id,
                    book_id: item.book_id,
                    book_name: item.book_name,
                    user_id: item.user_id,
                    user_name: item.user_name,
                    count:  item.count,
                }
                this.$root.tipSure({
                    scope: this,
                    info: '确定归还么？',
                    sure: function(){
                        this.ajax({
                            type: 'post',
                            data: obj,
                            url: '/api/borrow/remove/',
                            success: function(rel){
                                that.doSearch();
                            }
                        });
                    }
                });
            },
            // 续借
            reBorrow(item){
                var that = this;
                var obj = {
                    id: item._id,
                    book_id: item.book_id,
                    book_name: item.book_name,
                    user_id: item.user_id,
                    user_name: item.user_name,
                    count:  item.count,
                }
                this.$root.tipSure({
                    info: '确定续借么？',
                    scope: this,
                    sure: function(){
                        this.ajax({
                            type: 'post',
                            data: obj,
                            url: '/api/borrow/update/',
                            success: function(rel){
                                that.getData();
                            }
                        });
                    }
                });
            },
        }
    }
</script>