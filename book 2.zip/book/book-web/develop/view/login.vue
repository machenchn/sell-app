<style>
    
</style>

<template>
    <div class="book-login">
        <div class="login">
            <h3 class="login-header">登录</h3>
            <div class="login-content">
                <div class="cl">
                    <input type="text" 
                        class="text" 
                        v-model="submitObj.acount" 
                        @keyup="keyupInput($event)"
                        placeholder="账号">
                </div>
                <div class="cl">
                    <input type="password" 
                        class="text"
                        id="password"
                        v-model="submitObj.password" 
                        @keyup="keyupLogin($event)"
                        placeholder="密码">
                </div>
                <div class="login-tip">
                    <div>{{errMsg}}</div>
                </div>
                <div class="cl">
                    <button class="btn btn-primary" @click="login()">登录</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    var Alert = require('../components/alert.vue');
    module.exports =  {
        components: {
            Alert
        },
        data (){
            return {
                alert: {
                    show: false,
                    type: 'danger',
                    message: '' 
                },
                submitObj: {
                    name: '',
                    password: ''
                },
                errMsg: ''
            }
        },
        events: {
           
        },
        ready (){
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },

            // 显示提示框
            showAlert (type, message){
                this.$root.showAlert(this, type, message);
            },

            // 登录
            login (){
                var that = this;
                var subData = this.$root.trim(this.submitObj)
                this.ajax({
                    type: 'post',
                    url: '/api/user/login',
                    data: subData,
                    success (result){
                        // 缓存数据
                        localStorage.ksc_acount = result.data.acount;
                        localStorage.ksc_name = result.data.name;
                        localStorage.ksc_user_id = result.data._id;
                        localStorage.ksc_auth = result.data.auth;
                        localStorage.ksc_tell = result.data.tell;
                        localStorage.ksc_email = result.data.email;
                        localStorage.ksc_create_at = result.data.create_at;
                        that.$router.go('/board');
                    },
                    error (result){
                        that.errMsg = result.error_message;
                    }
                });
            },

            // keyup触发焦点到密码框
            keyupInput (event){
                if(event.keyCode == 13){
                    $('#password').focus();
                } else {
                    this.errMsg = '';
                }
            },
            // keyup触发登录
            keyupLogin (event){
                if(event.keyCode == 13){
                    this.login();
                } else {
                    this.errMsg = '';
                }
            },
            
        }
    }
</script>