<style>
    
</style>

<template>
    <section class="page-alert" v-show="alert.show">
        <Alert :show.sync="alert.show" :type.sync="alert.type">
            {{ alert.message }}
        </Alert>
    </section>
    <div class="ks-tab pb">
        <div class="tab-body">
            <div class="search-area">
                <div class="srh-cl clearfix">
                    <div class="srh-item">
                        <label class="srh-item-l">书名：</label>
                        <div class="srh-item-r">
                            <input type="text" 
                                v-model="srhParam.name"
                                @keyup="keyupSearch($event)"
                                placeholder="书名" 
                                class="text">
                        </div>
                    </div>
                    <button class="btn btn-primary btn-srh" @click="doSearch()">查询</button>
                    <button v-if="role<3" class="btn btn-primary-line btn-srh pull-right" @click="add()">添加</button>
                    <a v-if="role<3" download class="btn btn-primary-line btn-srh pull-right" href="/api/book/exports">导出</a>
                </div>
            </div>
            <div class="content-area">
                <div class="table-area">
                    <div class="table-wrap">
                        <table class="ks-table">
                            <thead>
                                <tr>
                                    <th nowrap>书名</th>
                                    <th nowrap>数量</th>
                                    <th nowrap>已借出</th>
                                    <th nowrap>单价</th>
                                    <th nowrap>作者</th>
                                    <th nowrap>出版社</th>
                                    <th nowrap>更新时间</th>
                                    <th nowrap>创建时间</th>
                                    <th nowrap v-if="role<3">操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in listData.lists">
                                    <td>{{item.name}}</td>
                                    <td>{{item.count}}</td>
                                    <td>{{item.borrow}}</td>
                                    <td>{{item.price}}</td>
                                    <td>{{item.author}}</td>
                                    <td>{{item.publisher}}</td>
                                    <td>{{item.update_at | date}}</td>
                                    <td>{{item.create_at | date}}</td>
                                    <td v-if="role<3">
                                        <a v-if="item.borrow==0" @click="del(item._id)" class="color-c">删除</a>
                                        <a @click="edit(item)">编辑</a>
                                        <a v-if="item.count>item.borrow" @click="borrow(item)">借出</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-area">
                        <Pagination 
                            :total-row="pagination.totalRow"
                            :page-size="pagination.per_page" 
                            :index="pagination.page" 
                            max-length="pagination.maxLength"
                            page-event="refreshPage"></Pagination>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <Dialog :show.sync="editFlag" :title="editTitle" btn='edit' button="确定" classname="dialog-type-a">
        <div class="interval-content">
            <div class="">
                <div class="cl">
                    <label class="cl-l">书名：</label>
                    <div class="cl-r">
                        <input type="text" 
                            :disabled="isEdit" 
                            class="text bs-input-width" 
                            v-model="submitObj.name"
                            placeholder="《人月神话》">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">数量：</label>
                    <div class="cl-r">
                        <input type="text" 
                            class="text bs-input-width" 
                            v-model="submitObj.count"
                            placeholder="1">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">价格：</label>
                    <div class="cl-r">
                        <input type="text" 
                            class="text bs-input-width" 
                            v-model="submitObj.price"
                            placeholder="14.89">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">作者：</label>
                    <div class="cl-r">
                        <input type="text" 
                            class="text bs-input-width" 
                            v-model="submitObj.author"
                            placeholder="张三丰">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">出版社：</label>
                    <div class="cl-r">
                        <input type="text" 
                            class="text bs-input-width" 
                            v-model="submitObj.publisher"
                            placeholder="人民教育出版社">
                    </div>
                </div>
            </div>
        </div>
    </Dialog>
    <Dialog :show.sync="borrowFlag" title="借出" btn='borrow' button="确定" classname="dialog-type-a">
        <div class="interval-content">
            <div class="">
                <div class="cl">
                    <label class="cl-l">数量：</label>
                    <div class="cl-r">
                        <input type="text" 
                            :disabled="isEdit" 
                            class="text bs-input-width" 
                            v-model="borrowObj.count"
                            placeholder="1">
                    </div>
                </div>
                <div class="cl">
                    <label class="cl-l">用户：</label>
                    <div class="cl-r">
                        <Select2 placeholder="请选择用户" 
                            :lists="userList"
                            :value.sync="borrowObj.user_id"
                            :name.sync="borrowObj.user_name"
                            class="bs-input-width"></Select2>
                    </div>
                </div>
            </div>
        </div>
    </Dialog>
</template>

<script>
    var Alert = require('../components/alert.vue');
    var Pagination = require('../components/pagination.vue');
    var Dialog = require('../components/dialog.vue');
    var Select2 = require('../components/select2.vue');
    module.exports =  {
        components: {
            Alert,
            Pagination,
            Dialog,
            Select2
        },
        data (){
            return {
                alert: {
                    show: false,
                    type: 'danger',
                    message: '' 
                },
                pagination: {
                    page: 1,
                    per_page: 10,
                    totalRow: 0,
                    maxLength: 5
                },
                listData: {
                    total: '',
                    lists:[]
                },
                isEdit: false,
                editFlag: false,
                editTitle: '',
                borrowFlag: false,
                borrowObj: {
                    user_id: '',
                    user_name: '',
                    book_id: '',
                    count: 1
                },
                currentItem: '',
                srhParam: {},
                submitObj: {
                    // id:'',
                    name: '',
                    count:1,
                    price: '',
                    author: '',
                    publisher: ''
                },
                role: localStorage.ksc_auth,
                userList: ''
            }
        },
        events: {
           'refreshPage': function (data) {
                this.pagination.page = data.index;
                this.pagination.per_page = parseInt(data.pageSize);
                this.getData();
            },
            // 编辑新建
            'on-edit-close' :function(){
                this.editFlag = false;
            },
            'on-edit-ok': function(){
                this.editSubmit();
            },
            // 借出
            'on-borrow-close' :function(){
                this.borrowFlag = false;
                this.clearBorrowObj();
            },
            'on-borrow-ok': function(){
                // this.selectFlag();
                this.borrowSubmit();
            },
        },
        ready (){
            this.getData();
            if(this.role < 3) {
                this.getUserList();
            }
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },

            // 显示提示框
            showAlert (type, message){
                this.$root.showAlert(this, type, message);
            },

            // 获取数据
            getData (){
                var that = this;
                this.srhParam.page = this.pagination.page;
                this.srhParam.per_page = this.pagination.per_page;
                this.ajax({
                    type: 'post',
                    data: this.srhParam,
                    url: '/api/book/list',
                    success (result){
                        that.listData.lists = result.data.list;
                        that.pagination.totalRow = result.data.total;
                    },
                    error (err){}
                });
            },
            // 查询按钮
            doSearch(){
                this.pagination.page = 1;
                this.getData();
            },
            // keyup触发搜索
            keyupSearch (event){
                if(event.keyCode == 13){
                    this.doSearch();
                }
            },

            // 查询单书
            // getUser (id){
            //     var that = this;
            //     this.ajax({
            //         type: 'get',
            //         url: '/api/book/detail/' + id,
            //         success (result){
            //             that.currentItem = result.data;
            //         },
            //         error (err){}
            //     });
            // },

            // 查询全部用户列表
            getUserList(){
                var that = this;
                this.ajax({
                    type: 'post',
                    data: this.srhParam,
                    url: '/api/user/list_all',
                    success (result){
                        that.userList = result.data;
                    },
                    error (err){}
                });
            },

            // 添加编辑
            add(){
                this.isEdit = false;
                this.editTitle = "添加";
                this.clearSubmitObj();
                this.submitObj.id = new Date().getTime();
                this.editFlag = true;
            },
            edit (item){
                this.isEdit = true;
                this.editTitle = "编辑";
                this.submitObj = $.extend({},item);
                this.editFlag = true;
            },
            editSubmit(){
                var that = this;
                var url;
                var obj = this.$root.trim(this.submitObj)
                if(this.isEdit) {
                    obj.id = obj._id;
                    url = '/api/book/update';
                    if(obj.count<obj.borrow){
                        this.showAlert('danger','总数量不能小于已借出的数量');
                        return false;
                    }
                } else {
                    url = '/api/book/add';
                }
                this.ajax({
                    type: 'post',
                    data: obj,
                    url: url,
                    success (result){
                        if(that.isEdit) {
                            that.getData();
                        } else {
                           that.doSearch();
                        }
                        that.editFlag = false;
                    },
                    error (err){}
                });
            },
            // 借出
            borrow(item){
                this.clearBorrowObj();
                this.borrowFlag = true;
                this.currentItem = item;
                this.borrowObj.book_id = item._id;
                this.borrowObj.book_name = item.name;
            },
            borrowSubmit(){
                var that = this;
                var obj = this.$root.trim(this.borrowObj);
                if (!obj.count || !obj.user_id) {
                    this.showAlert('danger', '输入参数不全');
                } else {
                    if(isNaN(obj.count)) {
                        this.showAlert('danger', '数量只能是字数');
                    } else if (parseInt(obj.count) + parseInt(this.currentItem.borrow) > parseInt(this.currentItem.count)) {
                        this.showAlert('danger', '超出上限');
                    } else {
                        this.ajax({
                            type: 'post',
                            data: obj,
                            url: '/api/book/borrow/',
                            success (result){
                                that.getData();
                                that.borrowFlag = false;
                            },
                            error (err){}
                        });
                    }
                }
            },
            del(id) {
                var that = this;
                this.$root.tipSure({
                    scope: this,
                    sure: function(){
                        this.ajax({
                            type: 'post',
                            data: {id: id},
                            url: '/api/book/remove',
                            success: function(rel){
                                that.doSearch();
                            }
                        });
                    }
                });
            },
            clearSubmitObj(){
                this.submitObj.name = '';
                this.submitObj.count = 1;
                this.submitObj.price = '';
                this.submitObj.author = '';
                this.submitObj.publisher = '';
            },
            clearBorrowObj(){
                this.borrowObj.book_id = '';
                this.borrowObj.user_id = '';
                this.borrowObj.user_name = '';
                this.borrowObj.count = 1;
            }
        }
    }
</script>