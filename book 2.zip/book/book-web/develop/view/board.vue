<style>
    
</style>

<template>
    <header class="beian-header">
        <div class="bh-content relative">
            <a class="logo" v-link="{name:'home'}"></a>
            <span class="bh-split"></span>
            <div class="bh-n1">图书馆借阅管理系统</div>
            <!-- <div class="bh-n2">新增/变更备案</div> -->
            <div class="bh-n3">
                <i class="icon icon-i-9"></i>
                <span>请务必记录真实有效的信息！</span>
            </div>
            <div class="bh-right">
                <span class="pull-left pointer color-a f12" @click="logout()">退出</span>
                <span class="bh-split-r"></span>
                <span class="bh-n5 f12 pointer" v-link="{name:'user'}">{{name}}</span>
            </div>
            <aside class="beian-nav">
                <Sidebar></Sidebar>
            </aside>
        </div>

    </header>
    <div class="book-body">
        <div class="book-body-in">
            <div class="beian-content">
                <div class="bc-in">
                    <router-view></router-view>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    var Sidebar = require('../components/sidebar.vue');
	module.exports =  {
        components: {
            Sidebar
        },
        data (){
            return {
                name: ''
            }
        },
        route: {
            data (){

            }
        },
        created (){
            this.name = localStorage.ksc_name;
        },
        methods: {
            // ajax
            ajax (obj){
                var that = this;
                this.$root.ajax(that,obj);
            },
            goPath(url){
                this.$route.router.go(url);
            },
            logout(){
                var that = this;
                this.$root.tipSure({
                    scope: this,
                    info: '确定要退出登录吗？',
                    sure: function(){
                        this.ajax({
                            type: 'post',
                            url: '/api/user/logout',
                            success (result){
                                localStorage.clear();
                                that.$route.router.go({name:'login'});

                            },
                        });
                    }
                });
                
                
            }
        }
    }
</script>