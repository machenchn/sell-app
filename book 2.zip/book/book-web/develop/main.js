'use strict';

var Vue = require('vue');
var Router = require('vue-router');

//load network view

var pageLogin = require('./view/login.vue'),
    pageBoard = require('./view/board.vue'),
    pageHome = require('./view/home.vue'),
    pageUser = require('./view/user.vue'),
    pageUserList = require('./view/userList.vue'),
    pageBookList = require('./view/bookList.vue'),
    pageBorrowList = require('./view/borrowList.vue'),
    pageHistoryList = require('./view/historyList.vue'),
    dataanalysis = require('./view/dataanalysis.vue');
    

//load commonJS
var common = require('./js/common.js');

Vue.use(Router); 

Vue.config.debug = true;



//引用指令
Vue.directive('ksIncDec',require('./directive/ksIncDec.js'));
// Vue.directive('sliderBar',require('./directive/sliderBar.js'));
Vue.directive('selectRadio',require('./directive/selectRadio.js'));
Vue.directive('selectBlock',require('./directive/selectBlock.js'));
Vue.directive('ksSelect',require('./directive/ksSelect.js'));



var initData;
var initMsgFilter = $.get('/api/init',function(result){
    if(result.data){
        Vue.use(common,{data: result.data});
        initData = result.data;
    }
},'json');
// Vue.use(common);

var router = new Router({
    hashbang: false
});
//set router
router.map({
    '/board': {
        name: 'board',
        component: pageBoard,
        subRoutes: {
            '/home': {
                name: 'home',
                title: '',
                component: pageHome
            },
            '/user': {
                name: 'user',
                title: '',
                component: pageUser
            },
            '/users': {
                name: 'users',
                title: '',
                component: pageUserList
            },
            '/books': {
                name: 'books',
                title: '',
                component: pageBookList
            },
            '/history': {
                name: 'history',
                title: '',
                component: pageHistoryList
            },
            '/analysis': {
                name: 'analysis',
                title: '',
                component: dataanalysis
            },
            '/borrow': {
                name: 'borrow',
                title: '',
                component: pageBorrowList
            },
        }
    },
    '/login': {
        name: 'login',
        component: pageLogin,
    }
});

// 路由切换前的处理
// router.beforeEach(function (transition){
//     if ($.cookie('ksc_book')){
//         if (transition.to.path == '/login') {
//             router.go('/board/home');
//         }
//         transition.next();
//     } else {
//         router.go('/login');
//         transition.next();
//     }
// });

router.redirect({
    '*': '/board',
    '/board': '/board/home'
});
!function check_path(){
    if (!$.cookie('ksc_book')){
        router.go('/login');
    }
}();

initMsgFilter.done(function(){
    var App = Vue.extend({
        data: function(){
            return {
                initData : initData,
                auth_check: {}

            }
        }
    });
    router.start(App, '#app');
});
// var App = Vue.extend({});
// router.start(App, '#app');


