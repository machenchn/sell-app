module.exports = {
    twoWay: true,
    priority: 1000,

    params: [
        'step',
        'max',
        'min'
    ],

    bind: function () {
        var self = this;
        var step = parseInt(self.params.step);
        var min = parseInt(self.params.min);
        var max = parseInt(self.params.max);

        this.el.innerHTML =[
            '<button>-</button>',
            '<input class="text-center" type="text" value="3">',
            '<button>+</button>'
        ].join('');

        $(this.el).find("button").first().click(function(){
            var exp_value = self.value - parseInt(step);

            if(exp_value >= min){
                self.value = exp_value;
                $(self.el).find("input").val(exp_value);
            }else{
                self.value = min;
                $(self.el).find("input").val(min);
            }
            self.set(self.value);
        });

        $(this.el).find("button").last().click(function(){
            var exp_value = self.value + parseInt(step);

            if(exp_value <= max){
                self.value = exp_value;
                $(self.el).find("input").val(exp_value);
            }else{
                self.value = max;
                $(self.el).find("input").val(max);
            }
            self.set(self.value);
        });

        $(this.el).find('input').on("change",function(){
            var exp_value = parseInt($(this).val());

            if(exp_value > max){
                self.value=max;
                $(this).val(max);
            }else if(exp_value < min){
                self.value=min;
                $(this).val(min);
            }else{
                self.value = exp_value;
            }

            self.set(self.value);
        })
    },
    update: function (value) {
        this.value = value;
        $(this.el).find("input").val(value);
    },
    unbind: function () {
        $(this.el).find('button').unbind('click');
        $(this.el).find('input').unbind('change');
    }
};
