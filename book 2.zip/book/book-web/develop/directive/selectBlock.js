module.exports = {
    twoWay: true,
    priority: 1000,

    params: ['options'],

    bind: function () {
        var self = this;

        var optionsDom = [];
        for(var key in this.params.options){
            optionsDom.push('<button type="button" class="ks-btn ks-btns-option" value="'+ this.params.options[key] +'">'+key+'</button>');
        }
        this.el.innerHTML =optionsDom.join('');

        $(this.el).find('button').click(function(){
            $(self.el).find('button').removeClass('ks-btns-active');
            $(this).addClass('ks-btns-active');
            self.set($(this).attr('value'));
        })
    },
    paramWatchers: {
        options:function(val, oldVal){
            $(this.el).find('button').unbind('click');

            var self = this;

            var optionsDom = [];
            for(var key in val){
                optionsDom.push('<button type="button" class="ks-btn ks-btns-option" value="'+ val[key] +'">'+key+'</button>');
            }
            this.el.innerHTML =optionsDom.join('');

            $(this.el).find('button').click(function(){
                $(self.el).find('button').removeClass('ks-btns-active');
                $(this).addClass('ks-btns-active');
                self.set($(this).attr('value'));
            })
        }
    },
    update: function (value) {
        $(this.el).find('[value = "' + value + '"]').trigger('click');
    },
    unbind: function () {
        $(this.el).find('button').unbind('click');
    }
};
