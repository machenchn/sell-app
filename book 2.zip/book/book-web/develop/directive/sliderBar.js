/*滑动条操作时,禁用user-select*/
function addUnselect(){
    $('body').addClass('ks-unselect');
}
function removeUnselect(){
    $('body').removeClass('ks-unselect');

}

module.exports = {
    twoWay: true,
    priority: 1000,
    params: [
        'max',
        'min',
        'step',
        'unit'
    ],
    bind: function (value) {
        this.el.innerHTML =[
            '<span class="left-text">',this.params.min,this.params.unit,'</span>',
            '<div class="progress" style="width:0%;">',
            '</div>',
            '<div class="slider">',
            '    <div class="line" ></div>',
            '</div>',
            '<span class="right-text">',this.params.max,this.params.unit,'</span>'
        ].join('');

        var progress = this.el.querySelector('.progress');
        var box = this.el;
        this.stepPerc = (this.params.step/(this.params.max-this.params.min)).toFixed(6);//百分比步长
        this.min = Number(this.params.min);

        this.setValue =  function(set_perc){
            if(set_perc < 0 || set_perc >1) return;

            var stepValue = (set_perc/this.stepPerc).toFixed(0);
            var realPerc = stepValue * this.stepPerc;

            if((realPerc !== this.perc) ||!this.perc){
                this.perc = realPerc;
                var value = stepValue * this.params.step;
                this.set(value+this.min);
            }
        }.bind(this);

        this.mouseUpProgress = function(){
            progress.style.width = this.perc*this.maxWidth + 'px';
        };

        var removeMoveListener = function(e){
            removeUnselect();

            this.mouseUpProgress();

            document.body.removeEventListener('mousemove', moveSlide, false);
            document.body.removeEventListener('mouseup', removeMoveListener, false);
        }.bind(this);

        var startSlide = function (e) {
            addUnselect();
            this.boxLeftOffset || (this.boxLeftOffset=getLeft(box)+8);
            this.maxWidth || (this.maxWidth=(box.offsetWidth-16))

            this.set_perc = (((e.clientX-this.boxLeftOffset) / this.maxWidth).toFixed(6));

            progress.style.width = this.set_perc*this.maxWidth + 'px';
            this.setValue(this.set_perc);

            document.body.addEventListener('mousemove', moveSlide, false);
            document.body.addEventListener('mouseup', removeMoveListener, false);
        }.bind(this);

        var moveSlide = function(e){
            this.set_perc = (((e.clientX-this.boxLeftOffset) / this.maxWidth).toFixed(6));

            progress.style.width = this.set_perc*this.maxWidth + 'px';
            this.setValue(this.set_perc);
        }.bind(this);

        box.addEventListener('mousedown', startSlide, false);

        function getLeft(e){
            var offset=e.offsetLeft;
            if(e.offsetParent!=null) {
                offset+=getLeft(e.offsetParent);
            }
            return offset;
        }
    },
    paramWatchers: {
        max: function (val, oldVal) {
            this.el.querySelector('.right-text').innerHTML=val+this.params.unit;
            this.stepPerc = (this.params.step/(this.params.max-this.params.min)).toFixed(6);
            this.min = Number(this.params.min);
        },
        min: function (val, oldVal) {
            this.el.querySelector('.left-text').innerHTML=val+this.params.unit;
            this.stepPerc = (this.params.step/(this.params.max-this.params.min)).toFixed(6);
            this.min = Number(this.params.min);
        },
        step: function (val, oldVal) {
            this.stepPerc = (this.params.step/(this.params.max-this.params.min)).toFixed(6);
            this.min = Number(this.params.min);
        }
    },
    update: function (value) {
        value = isNaN(value) ? 0 : parseInt(value)
        
        if(value < Number(this.params.min)){
            value = Number(this.params.min);
            this.set(value);
        }
        if(value >Number(this.params.max)){
            value = Number(this.params.max);
            this.set(value);
        }

        this.perc = ((value-this.params.min)/(this.params.max-this.params.min)).toFixed(6);
        this.el.querySelector('.progress').style.width = this.perc*100+'%';
    },
    unbind: function () {
        this.el.removeEventListener('mousedown', this.startSlide);
        this.el.removeEventListener('mouseup', this.startSlide);
    }
};