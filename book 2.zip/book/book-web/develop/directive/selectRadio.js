module.exports = {
    twoWay: true,
    priority: 1000,

    params: ['options'],

    bind: function () {
        var self = this;

        var optionsDom = [];
        for(var key in this.params.options){
            optionsDom.push('<li class="ks-radio-option" value="'+ this.params.options[key] +'">'+key+'</li>');
        }
        this.el.innerHTML =optionsDom.join('');

        $(this.el).find('li').click(function(){
            $(self.el).find('li').removeClass('ks-radio-active');
            $(this).addClass('ks-radio-active');
            self.set($(this).attr('value'));
        })
    },
    update: function (value) {
        $(this.el).find('[value = "' + value + '"]').trigger('click');
    },
    unbind: function () {
        $(this.el).find('li').unbind('click');
    }
};
