module.exports = {
    twoWay: true,
    priority: 1000,

    params: ['options'],

    bind: function () {
        var self = this;

        var leftOptionsDom = [];
        var rightOptionsDom = [];
        for(var leftKey in this.params.options){
            leftOptionsDom.push('<li>'+leftKey+'</li>');
            for(var rightKey in this.params.options[leftKey]){
                rightOptionsDom.push('<li class="hide" category="'+leftKey+'" value="' +this.params.options[leftKey][rightKey]+ '">'+rightKey+'</li>');
            }
        }
        this.el.innerHTML = '<ul class="ks-frame-select-left">'
            + leftOptionsDom.join('')
            +'</ul><ul class="ks-frame-select-right">'
            + rightOptionsDom.join('')
            +'</ul>';

        $(self.el).find('.ks-frame-select-right li').click(function(){
            $(self.el).find('.ks-frame-select-right li').removeClass('active');
            $(this).addClass('active');
            self.set($(this).attr('value'));
        });

        $(this.el).find('.ks-frame-select-left li').click(function(){
            $(self.el).find('.ks-frame-select-left li').removeClass('active');
            $(this).addClass('active');
            var leftKey  = $(this).text();

            $(self.el).find('.ks-frame-select-right li').addClass("hide");
            $(self.el).find('[category = "'+leftKey+'"]').removeClass("hide");

            /*判断是否有选中的镜像,如果没有选中第一个*/
            if($(self.el).find('.ks-frame-select-right li.active:not(.hide)').length === 0){
                $(self.el).find('.ks-frame-select-right li:not(.hide)').first().trigger('click');
            };
        });
    },
    update: function (value) {
        for(var leftKey in this.params.options){
            for(var rightKey in this.params.options[leftKey]){
                if(this.params.options[leftKey][rightKey] == value){
                    $(this.el).find('.ks-frame-select-right [value = "'+value+'"]').trigger('click');
                    $(this.el).find('.ks-frame-select-left li:contains(' +leftKey+ ')').trigger('click');
                    return;
                }
            }
        }
    },
    unbind: function () {
        $(this.el).find('li').unbind('click');
    }
};
