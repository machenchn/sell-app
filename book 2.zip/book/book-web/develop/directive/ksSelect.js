var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];

function generateMixed(n) {
    var res = "";
    for(var i = 0; i < n ; i ++) {
        var id = Math.ceil(Math.random()*35);
        res += chars[id];
    }
    return res;
}
module.exports = {
    twoWay: true,
    priority: 1000,

    params: ['options','supportAll','tipWord','selectWidth'],

    bind: function () {
        var self = this;
        var id = generateMixed(10);

        this.el.innerHTML =[
            '<button type="button" class="ks-btn ks-dropdown-text bi-dropdown-text">暂无数据<span class="ks-caret"></span></button>',
            '<ul id="',
            id,
            '" class="ks-dropdown-menu hide ks-dropdown-menu-toggle" style="width:' + this.params.selectWidth + '">',
            '</ul>'].join('');

        var optionsDom = [];

        if(typeof this.params.supportAll != 'undefined'&&this.params.supportAll == 'true'){
            optionsDom.push('<li><a href="javascript:void(0);">'+this.params.tipWord+'</a></li>');
        }
        // var a = {a:{b:1},d:3}
        // console.log(this.params.options)
        for(var key in this.params.options){
            optionsDom.push('<li value="'+ key +'"><a href="javascript:void(0);">' + this.params.options[key] + '</a></li>');
        }
        $(this.el).find('ul').html(optionsDom.join(''));
        $(this.el).find('button').click(function(e){
            if($('.ks-dropdown-menu-toggle').not('.hide').not('#'+id).length > 0){
                $('.ks-dropdown-menu-toggle').addClass('hide');
            }
            $('#'+id).toggleClass('hide');
            e.stopPropagation();
        });

        this.hideMenu = function(){
            $(self.el).find('ul').addClass('hide');
        }
        $('body').click(this.hideMenu);

        $(this.el).find('li').click(function(){
            $(self.el).find("button").html('<span class="ks-caret"></span>'+$(this).find('a').text());
            $(self.el).find('ul').addClass("hide");
            self.set($(this).attr('value'));
        })
    },
    paramWatchers: {
        options:function(val, oldVal){
            $(this.el).find('li').unbind('click');
            var self = this;

            var optionsDom = [];
            optionsDom.push('<li><a href="javascript:void(0);">' + this.params.tipWord + '</a></li>');
            for(var key in val){
                optionsDom.push('<li value="'+ key +'"><a href="javascript:void(0);">'+val[key]+'</a></li>');
            }
            $(this.el).find('ul').html(optionsDom.join(''));

            $(this.el).find('li').click(function(){
                $(self.el).find("button").html('<span class="ks-caret"></span>'+$(this).find('a').text());
                $(self.el).find('ul').addClass("hide");
                self.set($(this).attr('value'));
            })
        }
    },
    update: function (value) {
        /*支持全部选项时,没有初始值默认全部*/
        if(typeof this.params.supportAll != 'undefined'&&this.params.supportAll == 'true'&& value==''){
            $(this.el).find('li').first().trigger('click');
        }

        $(this.el).find('[value = "' + value + '"]').trigger('click');
    },
    unbind: function () {
        $(this.el).find('li').unbind('click');
        $('body').unbind('click',this.hideMenu);
    },

};
