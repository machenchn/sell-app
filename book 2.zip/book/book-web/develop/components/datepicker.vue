<style>
    .datetime-picker {
        position: relative;
        display: inline-block;
        color: #333;
        vertical-align: bottom;
    }

    .datetime-picker * {
        box-sizing: border-box;
    }

    .datetime-picker input {
        width: 100%;
        padding: 5px 10px;
        height: 29px;
        outline: 0 none;
        border: 1px solid #ccc;
        font-size: 12px;
    }

    .datetime-picker .picker-wrap {
        position: absolute;
        z-index: 10000;
        width: 238px;
        /*height: 280px;*/
        margin-top: 2px;
        background-color: #fff;
        box-shadow: 0 0 6px #ccc;
    }

    .datetime-picker table {
        width: 100%;
        border-collapse:inherit;
        border-spacing: 0;
        text-align: center;
        font-size: 13px;
        padding:9px;
    }

    .datetime-picker tr {
        height: 34px;
        border: 0 none;
    }

    .datetime-picker th, .datetime-picker td {
        user-select: none;
        width: 34px;
        height: 34px;
        padding: 0;
        line-height: 32px;
        text-align: center;
    }

    .datetime-picker td {
        border: solid 1px #ffffff;
        cursor: pointer;
    }

    .datetime-picker td:hover,.datetime-picker td.date-active {
        color: #2283d0;
        background-color: #ebf5fe;
        border-color:#289af4;
    }

    .datetime-picker td.date-pass, .datetime-picker td.date-future {
        color: #aaa;
    }

    .datetime-picker .date-head {
        background-color: #ffffff;
        text-align: center;
        color: #333;
        font-size: 14px;
    }

    .datetime-picker .triangle{
        display: inline-block;
        width: 23px;
        height: 34px;
        cursor: pointer;
    }
    .datetime-picker .triangle:after{
        content: "";
        display: inline-block;
        border-width: 5px;
        border-style: solid;
        border-color: transparent;
    }
    .datetime-picker .triangle-left:after {
        border-right-color: #9f9f9f;
    }
    .datetime-picker .triangle-right:after {
        border-left-color: #9f9f9f;
    }

    .datetime-picker .date-days {
        color: #888888;
        font-size: 14px;
    }

    .datetime-picker .date-days th{
        font-weight: normal;
        border-bottom: 1px solid #eaeaea;
    }

    .datetime-picker .show-year {
        display: inline-block;
        min-width: 62px;
        vertical-align: middle;
    }

    .datetime-picker .show-month {
        display: inline-block;
        min-width: 28px;
        vertical-align: middle;
    }

    .datetime-picker .btn-prev,
    .datetime-picker .btn-next {
        cursor: pointer;
        display: inline-block;
        padding: 0 10px;
        vertical-align: middle;
    }

    .datetime-picker .btn-prev:hover,
    .datetime-picker .btn-next:hover {
        background: rgba(16, 160, 234, 0.5);
    }
    /* add timepicker */
    .time-picker{
        width: 100%;
        height: 32px;
        text-align: center;
    }
    .datetime-picker input.timer-picker-input{
        width: 60px;
        text-align: center;
    }
    .date-picker-btns{
        width: 100%;
        overflow: hidden;
        padding:6px 10px;
        text-align: right;
    }
    .datepicker-btn{
        display: inline-block;
        /*float: right;*/
        color: #444;
        background-color: #fff;
        border: 1px solid #aaa;
        width: 54px;
        height: 30px;
        text-align: center;
        line-height: 30px;
        border-radius: 4px;
        font-size: 12px;
        cursor: pointer;
    }
    .datepicker-btn-ok{
        color: #fff;
        background-color: #28a1fc;
        border: 1px solid #28a1fc;
        margin-left: 10px;
    }
</style>

<template>
    <div class="datetime-picker" :style="{ width: width }">
        <input
                type="text"
                :style="styleObj"
                :readonly="readonly"
                :value="value"
                @click="show = !show">
        <div class="picker-wrap" v-show="show">
            <table class="date-picker">
                <thead>
                <tr class="date-head">
                    <th colspan="4">
                        <span class="triangle triangle-left" @click="yearClick(-1)"></span>
                        <span class="show-year">{{now.getFullYear()}}</span>
                        <span class="triangle triangle-right" @click="yearClick(1)"></span>
                    </th>
                    <th colspan="3">
                        <span class="triangle triangle-left" @click="monthClick(-1)"></span>
                        <span class="show-month">{{months[now.getMonth()]}}</span>
                        <span class="triangle triangle-right" @click="monthClick(1)"></span>
                    </th>
                </tr>
                <tr class="date-days">
                    <th v-for="day in days">{{day}}</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="i in 6">
                    <td v-for="j in 7"
                        :class="date[i * 7 + j] && date[i * 7 + j].status"
                        :date="date[i * 7 + j] && date[i * 7 + j].date"
                        @click="pickDate(i * 7 + j)">{{date[i * 7 + j] && date[i * 7 + j].text}}</td>
                </tr>
                </tbody>
            </table>
            <div class="time-picker" v-show="type === 'time'">
                <input class="timer-picker-input" type="text"
                       v-model="time.H"
                       @blur.stop="watchTime('H')"> :
                <input class="timer-picker-input" type="text"
                       v-model="time.M"
                       @blur.stop="watchTime('M')"> :
                <input class="timer-picker-input" type="text"
                       v-model="time.S"
                       @blur.stop="watchTime('S')">
            </div>
            <div class="date-picker-btns" >
                <a class="datepicker-btn" @click.stop="clearTime">清 空</a>
                <a v-show="type === 'time'" class="datepicker-btn datepicker-btn-ok" @click.stop="pickTime">确 定</a>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            width: { type: String, default: '238px' },
            readonly: { type: Boolean, default: false },
            value: { type: String, default: '' },
            format: { type: String, default: 'YYYY-MM-DD' },
            type: {type: String, default: 'date'} //time
        },
        data:function(){
        return {
            show: false,
            days: ['日', '一', '二', '三', '四', '五', '六'],
            months: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
            date: [],
            now: new Date(),
            time: {
                H: '23',
                M: '59',
                S: '59'
            }
        };
    },
    watch: {
        now:function(){
            this.update();
        },
        show:function(){
            this.update();
        }
    },
    methods: {
        close:function(){
            this.show = false;
        },
        update:function(){
            var arr = [];
            var time = new Date(this.now);
            time.setMonth(time.getMonth(), 1);           // the first day
            var curFirstDay = time.getDay();
            curFirstDay === 0 && (curFirstDay = 7);
            time.setDate(0);                             // the last day
            var lastDayCount = time.getDate();
            for (let i = curFirstDay; i > 0; i--) {
                arr.push({
                    text: lastDayCount - i + 1,
                    time: new Date(time.getFullYear(), time.getMonth(), lastDayCount - i + 1),
                    status: 'date-pass'
                });
            }

            time.setMonth(time.getMonth() + 2, 0);       // the last day of this month
            var curDayCount = time.getDate();
            time.setDate(1);                             // fix bug when month change
            var value = this.value || this.stringify(new Date());
            for (let i = 0; i < curDayCount; i++) {
                let tmpTime = new Date(time.getFullYear(), time.getMonth(), i + 1);
                let status = '';
                this.stringify(tmpTime) === value && (status = 'date-active');
                arr.push({
                    text: i + 1,
                    time: tmpTime,
                    status: status
                });
            }

            var j = 1;
            while (arr.length < 42) {
                arr.push({
                    text: j,
                    time: new Date(time.getFullYear(), time.getMonth() + 1, j),
                    status: 'date-future'
                });
                j++;
            }
            this.date = arr;
        },
        yearClick:function (flag) {
            this.now.setFullYear(this.now.getFullYear() + flag);
            this.now = new Date(this.now);
        },
        monthClick:function (flag) {
            this.now.setMonth(this.now.getMonth() + flag);
            this.now = new Date(this.now);
        },
        pickDate:function (index) {
            this.type === 'date' && (this.show = false);
            this.now = new Date(this.date[index].time);
            this.value = this.stringify();
        },
        pickTime: function (){
            this.value = this.stringify();
            this.close();
        },
        clearTime: function (){
            this.value = '';
            // this.close();
        },
        parse:function (str) {
            var time = new Date(str);
            return isNaN(time.getTime()) ? null : time;
        },
        watchTime: function(str){
            if(this.time[str].length === 1){
                this.time[str] = '0' + this.time[str];
            }
            if(this.time[str].length > 2){
                this.time[str] = this.time[str].slice(-2);
            }
            // if(str === 'M' || str === 'S'){
            //     if(this.time[str] >= 60 || this.time[str] === '' || isNaN(parseInt(this.time[str]))){
            //         this.time[str] = '59';
            //     }
            // }
            // else{
            //     if(this.time[str] >= 24 || this.time[str] === '' || isNaN(parseInt(this.time[str]))){
            //         this.time[str] = '23';
            //     }
            // }
            var reg = /^\d+$/;
            if(str === 'M' || str === 'S'){
                if(this.time[str] >= 60 || this.time[str] === '' || !reg.test(this.time[str])){
                    this.time[str] = '59';
                }
            }
            else{
                if(this.time[str] >= 24 || this.time[str] === '' || !reg.test(this.time[str])){
                    this.time[str] = '23';
                }
            }
        },
        stringify:function (time = this.now, format = this.format) {
            var year = time.getFullYear();
            var month = time.getMonth() + 1;
            var date = time.getDate();
            var monthName = this.months[time.getMonth()];

            var map = {
                YYYY: year,
                MMM: monthName,
                MM: ('0' + month).slice(-2),
                M: month,
                DD: ('0' + date).slice(-2),
                D: date
            };
            if(this.type === 'time'){
                map.hh = this.time.H;
                map.mm = this.time.M;
                map.ss = this.time.S;
            }
            return format.replace(/Y+|M+|D+|h+|m+|s+/g, function (str) {
                return map[str];
            });
        }
    },
    ready:function(){
        this.now = this.parse(this.value) || new Date();
        document.addEventListener('click', (e) => {
            try {
                    if (!this.$el.contains(e.target)) {
                        //this.type === 'date' && this.close();
                        this.close();
                    }
                } catch (e) {
                }
        }, false);
    },
    beforeDestroy:function(){
        document.removeEventListener('click', this.close, false);
    }
    };
</script>