<style>
    .aside-nav{
        overflow: auto;
        height: 100%;
        background-color: #eae9e9;
    }
    .aside-nav a{
        display: block;
        width: 100%;
        height: 40px;
        line-height: 40px;
    }
    
    .nav-title{
        padding-left: 10px;
        /*background-color: #fff;*/
        position: relative;
        border-left: 5px solid transparent;
    }
    .nav-li.current .nav-title{
        background-color: #f8f8f8;
        border-left-color: #eb544d;
    }
    .nav-title .icon{
        position: absolute;
        right: 10px;
        top:14px;
        color:#333;
    }
    .nav-title .icon-up-10{
        display: block;
    }
    .nav-title .icon-down-10{
        display: none;
    }
    .open .nav-title .icon-up-10{
        display: none;
    }
    .open .nav-title .icon-down-10{
        display: block;
    }
</style>

<template>
    <div class="aside-nav">
        <ul class="nav-ul">
            <li class="nav-li">
                <a class="nav-title" _label="home" @click="go('home')">首页</a>
            </li>
            <li class="nav-li">
                <a class="nav-title" _label="borrow" @click="go('borrow')">借阅管理</a>
            </li>
            <li class="nav-li">
                <a class="nav-title" _label="books" @click="go('books')">图书列表</a>
            </li>
            <li class="nav-li">
                <a class="nav-title" _label="users" @click="go('users')">用户列表</a>
            </li>
            <li class="nav-li">
                <a class="nav-title" _label="history" @click="go('history')">借阅记录</a>
            </li>
            <li class="nav-li">
                <a class="nav-title" _label="analysis" @click="go('analysis')">数据分析</a>
            </li>
        </ul>
    </div>
    
</template>


<script>
    module.exports = {
        name: 'Sidebar',
        data (){
            return {
                role: ''
            }
        },
        props: [
           'type'
        ],
        created (){
            
        },
        ready (){
            this.checkNav();
            this.$watch('$route.path',function(){
                this.checkNav();
            });

            this.role = $.cookie('ksc_book').substr($.cookie('ksc_book').length-1,1);
        },
        methods: {
            checkNav: function(){
                var pathName = this.$route.name,
                    $a = $('[_label="'+pathName+'"]');

                $('.nav-li').removeClass('current');
                $a.parents('.nav-li').addClass('current');

            },
            go: function(name, opt){
                var option = opt || {};
                this.$route.router.go({
                    name :name, 
                    params: option
                });
            }
        }
    }
</script>