<style>
    .modal-enter, .modal-leave {
        opacity: 0;
    }

    .modal-enter .ks-alert,
    .modal-leave .ks-alert {
        opacity: 1;
    }
    .ks-alert-box{
        transition: opacity .3s ease;
    }
    .ks-alert-box .ks-alert a{
        color: #fff;
        position: relative;
        top: 2px;
    }
    .ks-alert-box .ks-alert{
        margin-bottom: 0;
    }
    .ks-alert-success .close{
        display: none;
    }
</style>

<template>
    <div class="ks-alert-box" v-show="show" transition="modal">
        <div :class="'ks-alert ks-alert-' + type" >
            <a href="javascript:void(0)" class="close" @click="show=false" ><span class="icon icon-close-20"></span></a>
            <slot></slot>
        </div>
    </div>
</template>


<script>
    module.exports = {
        name: 'Alert',
        data (){
            return {
                timer: null
            }
        },
        props: {
            type: {
                type: String,
                required: true
            },
            show: {
                type: Boolean,
                required: true,
                twoWay: true,
                default: false
            },
            duration: {
                type: Number,
                default: 3000
            }
        },
        created (){
            this.$watch('show', function(){
                this.closeAlert();
            });
            this.$watch('type', function(){
                this.closeAlert();
            });
        },
        methods: {
            closeAlert (){
                if(!this.show) return;
                var that = this;
                if(this.type === 'danger' || this.type === 'warning'){
                    clearTimeout(this.timer);
                    return;
                }
                if(this.timer) clearTimeout(this.timer);
                this.timer = setTimeout(function(){
                    that.show = false;
                }, that.duration);
            }
        }
    }
</script>