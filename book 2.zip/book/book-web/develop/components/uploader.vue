<style>
    
</style>

<template>
    <div class="upload-card">
        <div class="upload-card-title">{{title}}</div>
        <div class="upload-card-body">
            <div class="uc-body-in {{bgClass}}" :style="{height: height, width: width}">
                <div v-show="tip" class="upload-tip">{{message}}</div>
                <div class="upload-img" :style="{'background-img': url}"></div>
                <div class="btn btn-primary step-btn upload-btn">
                    <span class="upload-sp" @click="triggerClick()">本地上传</span>
                    <input type="file" class="upload-input" @change="cnahgeFile($event)">
                </div>
            </div>
            <i v-if="url" class="icon icon-search-20 to-biger" @click="$root.showPic(url)"></i>
            <div v-if="uploading" class="upload-loading">
                <div class="upload-loading-in" :style="{width: loadedPer}"></div>
            </div>
            
        </div>
    </div>
</template>


<script>
    module.exports = {
        name: 'Uploader',
        data (){
            return {
                tip: false,
                uploading: false,
                message: '',
                loadedPer: '55%',
                url: 'http://abc.ksyun.com/build/img/b1.png',
            }
        },
        props: [
            'upload',       // 双向绑定传的model
            'bgClass',      // 背影图片
            'title',        // 图片标题
            'width',        // 国片宽度
            'height',       // 图片高度
        ],
        created (){

        },
        methods: {
            triggerClick (){
                $(this.$el).find('[type="file"]').trigger('click');
            },
            cnahgeFile($event){
                this.upload($event.target.files[0]);
            },
            // 图片上传
            upload (file){
                var that = this;
                var url =  '/Api/resource/upload';
                var xhr = new XMLHttpRequest();
                var fd = new FormData();
                var maxFileSize = 1024*1024*5;  // 5M

                if(file.size >= maxFileSize ){  

                    this.message = '文件大小超限';
                    this.tip = true;

                }else{

                    // 开始上传
                    this.uploading = true;
                    
                    // 清空错误信息
                    this.message = '';
                    this.tip = false;

                    xhr.open("POST", url, true);

                    // 上传结果
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState == 4 && xhr.status == 200) {
                            
                            var data = $.parseJSON(xhr.responseText);
                            $(that.$el).find('[type="file"]').val('');
                            
                            if(data.ErrNo == 0){

                                var json = data.Result[0];
                            }else{
                                that.message='上传失败，请重试';
                                that.tip = true;
                                // 清空input-file的值
                            }

                        }
                    };

                    // 进度条
                    xhr.upload.onprogress = function(evt){
                        var loaded = evt.loaded,
                            total = evt.total;
                        that.loadedPer = Math.floor(100*loaded/total) + '%';
                    };  

                    fd.append("upload_file", file);
                    xhr.send(fd);


                }
            },
        }
    }
</script>