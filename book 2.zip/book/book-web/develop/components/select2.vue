<style>
    .select2{
        position: relative;
        height: 31px;
    }
    .select2-in{
        position: absolute;
        z-index: 10;
        border: solid 1px rgba(0,0,0,.1);
        border-radius: 0 0 3px 3px;
        overflow: hidden;
        min-width: 100px;
        width: 100%;
    }
    .select2-top{
        height: 29px;
        border-bottom-width:0;
        position: relative;
    }
    .select2-body{
        background-color: #fff;
        /*box-shadow: 0 1px 0 1px rgba(0,0,0,.1);*/
        padding-bottom: 6px;
    }
    .select2-srh{
        padding:8px 10px;
        border-top: solid 1px rgba(0,0,0,.1);
        background-color: #f7f7f7;
    }
    .select2-text{
        width: 100%;
        height: 29px;
        line-height: 29px;
        padding:0 6px;
        border: solid 1px rgba(0,0,0,.1);
        outline: 0;
        font-size: 12px;
    }
    .select2-bgtext{
        border:0;
    }
    .select2-text:focus{
        border-color: #006cff;
    }
    .select2-content{
        height: 120px;
        overflow: auto;
    }
    .select2-ul{
        padding:5px 10px;
    }
    .select2-li{
        line-height: 28px;
        border-radius: 2px;
        padding-left: 10px; 
        cursor: pointer;
        font-size: 13px;
    }
    .select2-li:hover{
        background-color: #f5f5f5;
        color:#006cff;
    }
    .select2-selval{
        position: absolute;
        left: 0;
        top:0;
        z-index: 2;
        width: 100%;
        height: 100%;
        cursor: pointer;
        line-height: 29px;
        padding-left: 10px;
        color:#666;
        padding-right: 20px;
    }
    .select2-selval i{
        position: absolute;
        right: 10px;
        top:9px;
        z-index: 2;
    }
</style>

<template>
    <div class="select2">
        <div class="select2-in">
            <div class="select2-top">
                <input type="text"
                    v-show="!name"
                    class="select2-text select2-bgtext" 
                    placeholder="{{placeholder}}">
                <div class="select2-selval" @click="open=!open">
                    {{name}}
                    <i class="icon" :class="{'icon-up-10':!open,'icon-down-10':open}"></i>
                </div>
            </div>
            <div v-show="open" class="select2-body">
                <div class="select2-srh">
                    <input type="text" 
                        class="select2-text" 
                        v-model="searchKey"
                        placeholder="回车键查询">
                </div>
                <div class="select2-content">
                    <ul class="select2-ul">
                        <li class="select2-li" 
                            @click="select(showSelectItem)">{{showSelectItem.name}}</li>
                        <li class="select2-li" 
                            v-for="item in lists | filterBy searchKey in 'name' 'full_chars' 'camel_chars'"
                            @click="select(item)">{{item.name}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
</template>


<script>
    module.exports = {
        name: 'Select2',
        data (){
            return {
                open: false,
                searchKey: '',
                showSelectItem: {
                    id: '',
                    name: this.showSelect || '请选择'
                }
            }
        },
        props: [
           'type',
           'placeholder',
           'lists',
           'value',
           'name',
           'options',
           'showSelect'
        ],
        created (){
            
        },
        ready (){
            if(this.showAll) {
                console.log(11)
            }
        },
        methods: {
            select(item){
                this.open = false;
                this.value = item._id;
                this.name = item.name;
            },
            keyupInput(){

            }
        }
    }
</script>