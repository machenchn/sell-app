<style>
.ks-btns-page .ellipsis{
    cursor: pointer;
}
.ks-btns-page .ks-pagination-space-right{
     margin-right: 10px;
 }
.ks-btns-page .ks-pagination-space-left{
    margin-left: 10px !important;
}
.pagination-go{
    display: inline-block;
    margin-right: 8px;
}
.pagination-go input{
    width: 40px;
    height: 31px;
    border:1px solid #ccc;
    outline: 0;
    box-shadow: none;
    text-align: center;
}
.pagination-go input.page_error{
    border-color:#eb544d;
}
.pagination-go button{
    height: 31px;
    font-size: 14px;
    width: 36px;
    border:1px solid #ccc;
    font-size: 12px;
    padding:0;
    color:#666;
    border-radius: 2px;
    background-color: #fff;
    cursor: pointer;
    outline: 0;
    box-shadow: none;
}
.pagination-go button.disabled{
    cursor: auto;
    background-color: #f0f0f0;
    color:#999;
}
.pagination-txt{
    display: inline-block;
    height: 28px;
    line-height: 28px;
}
</style>
<template>
    <div class="ks-btns-page">
        <div class="pager">
            <a href="javascript:void(0);" class="prev" @click="prev" :class="{'ks-pagination-space-right':pagerBtn.startIndex==1}">
                <span class="prev-caret"></span>
            </a>
            <a v-if="pagerBtn.startIndex > 1" class="ellipsis" @click="prevPage">...</a>

            <a v-for="num in pagerBtn.btnLen" :class="{ 'active': pagerBtn.index == num+pagerBtn.startIndex}"
               @click="btnClick(num+pagerBtn.startIndex,$event)">{{num+pagerBtn.startIndex}}</a>

            <a v-if="pagerBtn.btnLen + pagerBtn.startIndex -1 < pageNum" class="ellipsis" @click="nextPage">...</a>
            <a href="javascript:void(0);" class="next" @click="next" :class="{'ks-pagination-space-left':pagerBtn.btnLen + pagerBtn.startIndex -1 == pageNum}">
                <span class="next-caret"></span>
            </a>
        </div>
        <div class="pagination-go">
            <input type="text" 
                v-model="target" 
                :class="{'page_error':errorFlag}"
                @keyup="keyupGo(target,$event)">
            <button @click="go(target)">跳转</button>
        </div>
        <span class="pagination-txt">每页</span>

        <div class="ks-dropdown" v-ks-select="selectedPageSize" :options="pageSizeOptions"></div>
        <span class="pagination-txt">共{{totalRow}}条</span>
    </div>
</template>
<script>
    module.exports = {
        name: 'Pager',
        props: [
            'totalRow',
            'pageSize',
            'index',
            'maxLength',
            'pageEvent'
        ],
        data: function () {
            return {
                selectedPageSize: 10,
                pageSizeOptions: {
                    10: "10行",
                    15: "15行",
                    20: "20行"
                },
                pagerBtn: {
                    btnLen: 5,
                    startIndex: 1,
                    index: 0,
                    btnLenMax: 5
                },
                pageNum: 5,
                target:1,
                errorFlag: false
            }
        },
        methods: {
            btnClick: function (num, event) {
                if (event.target.className.indexOf('active')>=0) return false;
                this.pagerBtn.index = num;
                this.dispatch({
                    index: this.pagerBtn.index,
                    pageSize: this.selectedPageSize
                });
            },
            initPageNum: function () {
                let value = this.totalRow == 0 ? 1 : this.totalRow;
                let pageNum = Math.ceil(value / this.selectedPageSize);
                this.pageNum = pageNum == 0 ? 1 : pageNum;

                this.pagerBtn.btnLen = pageNum <= this.pagerBtn.btnLenMax ? pageNum : this.pagerBtn.btnLenMax;
            },
            prev: function () {
                if (this.pagerBtn.index - 1 > 0) {
                    this.pagerBtn.index = this.pagerBtn.index - 1;

                    this.dispatch({
                        index: this.pagerBtn.index,
                        pageSize: this.selectedPageSize
                    });
                }
            },
            next: function () {
                if (this.pagerBtn.index + 1 <= this.pageNum) {
                    this.pagerBtn.index = this.pagerBtn.index + 1;

                    this.dispatch({
                        index: this.pagerBtn.index,
                        pageSize: this.selectedPageSize
                    });
                }
            },
            prevPage: function () {
                if (this.pagerBtn.btnLen == this.pagerBtn.btnLenMax) {
                    if (this.pagerBtn.startIndex - this.pagerBtn.btnLenMax >= 0) {
                        this.pagerBtn.startIndex = this.pagerBtn.startIndex - this.pagerBtn.btnLenMax;
                    } else {
                        this.pagerBtn.startIndex = 1;
                    }
                }
            },
            nextPage: function () {
                if (this.pagerBtn.btnLen == this.pagerBtn.btnLenMax) {
                    if (this.pagerBtn.startIndex + this.pagerBtn.btnLenMax * 2 <= this.pageNum) {
                        this.pagerBtn.startIndex = this.pagerBtn.startIndex + this.pagerBtn.btnLenMax;
                    } else {
                        this.pagerBtn.startIndex = this.pageNum - this.pagerBtn.btnLenMax + 1;
                    }
                }
            },
            keyupGo: function(num,$event){

                if($event.keyCode == 13) {
                    this.go(num)
                }
            },
            checkInput: function(num){
                this.errorFlag = false;
                var num = '' + num;
                num = num.replace(/\s*/,'');

                if(!num) {
                    this.errorFlag = true;
                    return false;
                }

                var reg = /^[1-9]+\d*$/;
                if (!reg.test(num)) {
                    this.errorFlag = true;
                }
                // 是否超过了最大页数
                if (num > Math.ceil(this.totalRow/this.selectedPageSize) && num != 1){
                    this.errorFlag = true;
                }
            },
            // 页码跳转
            go: function(num){
                if (!this.errorFlag) {
                    this.pagerBtn.index = parseInt(num,10);
                    this.dispatch({
                        index: this.pagerBtn.index,
                        pageSize: this.selectedPageSize
                    });
                }
            },
            dispatch: function (data) {
                this.$dispatch(this.pageEvent, data);
            }
        },
        created: function () {
            this.selectedPageSize = this.pageSize;
            this.initPageNum();
            this.pagerBtn.index = this.index;

            this.target = this.index;

            /*外部传入总条数变化时重新初始化总页数*/
            this.$watch('totalRow', function (value) {
                this.initPageNum();
            });

            this.$watch('pageSize', function (value) {
                
                if(this.selectedPageSize != this.pageSize){
                    this.selectedPageSize = this.pageSize;
                }
                this.initPageNum();
            });

            this.$watch('index', function (value) {
                this.pagerBtn.index = value;
            });

            this.$watch('target', function (value) {
                this.checkInput(value);
            });

            /*当当前页变化时,尽量将当前页码置中*/
            this.$watch('pagerBtn.index', function (index) {
                this.target = index;
                this.errorFlag = false;
                let left = parseInt(this.pagerBtn.btnLenMax / 2);
                let right = left;
                if (index - left > 0 && (this.pageNum - (index + right) > 0)) {
                    this.pagerBtn.startIndex = index - left;
                } else if (index - left <= 0) {
                    this.pagerBtn.startIndex = 1;
                } else if (this.pageNum - (index + right) <= 0) {
                    this.pagerBtn.startIndex = (this.pageNum - this.pagerBtn.btnLenMax) <= 0 ? 1 : (this.pageNum - this.pagerBtn.btnLenMax + 1);
                }
            });
        },
        ready:function(){
            /*每页行数变化时更新页,此时页码请求置为1*/
            this.$watch('selectedPageSize', function (value) {
                this.pagerBtn.index=1;
                this.target = 1;
                this.dispatch({
                    index: 1,
                    pageSize: value
                });
            });
        },
        destroyed: function () {

        }
    }
</script>