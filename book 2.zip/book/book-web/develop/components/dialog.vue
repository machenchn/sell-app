<style>
    .modal-enter, .modal-leave {
        opacity: 0;
    }

    .modal-enter .ks-modal-dialog,
    .modal-leave .ks-modal-dialog {
        -webkit-transform: scale(1.1);
        transform: scale(1.1);
    }
</style>

<template>
        <div class="modal-mask {{classname}}" v-show="show" transition="modal" >
            <div :class="'modal-wrapper ks-modal-' + type">
                <div class="ks-modal-dialog">
                    <div class="ks-modal-content">
                        <div class="ks-modal-header">
                            <a href="javascript:void(0)" class="close">
                                <span class="icon icon-close-20" @click="dispatch($event, 'on-' + btn + '-close')"></span>
                            </a>
                            <h2 class="ks-modal-title">
                                {{ title }}
                            </h2>
                        </div>
                        <div class="ks-modal-body h3">
                            <slot>

                            </slot>
                        </div>
                        <div class="ks-modal-footer">
                            <button type="button"
                                    class="ks-btn ks-btn-primary"
                                    id="ks_dialog_btnok"
                                    :class="classname ? classname : '' "
                                    :disabled="isLoading"
                                    @click="dispatch($event,  'on-' + btn + '-ok')">
                                <span v-show="!isLoading">
                                    {{button}}
                                </span>
                                <span class="ks-dialog-loading" v-show="isLoading"></span>
                            </button>
                            <button type="button"
                                    v-if="cancel!='hidden'"
                                    @click="dispatch($event, 'on-' + btn + '-close')"
                                    class="ks-btn ks-btn-default">
                                取 消
                            </button>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
</template>

<script>
    module.exports = {
        name: 'Dialog',
        data (){
            return {
                isLoading: false
            }
        },
        props: {
            type: {
                type: String,
                required: false
            },
            title: {
                type: String,
                required: true
            },
            show: {
                type: Boolean,
                required: true
            },
            loading: {
                type: String
            },
            time: {
                type: String
            },
            btn: {
                type: String,
                required: false
            },
            button: {
                type: String,
                required: false,
                default: '确定'
            },
            cancel: {
                type: String,
                required: false,
                default: 'show'
            },
            classname: {
                type: String
            }
        },
        created (){
            this.$watch('show', function(){
                this.isLoading = false;
            });
        },
        methods: {
            dispatch(event, eventStr) {
                var that = this;
                if(this.loading === 'yes' && (event.target.id === 'ks_dialog_btnok' || event.target.parentNode.id === 'ks_dialog_btnok')){
                    this.isLoading = true;
                    setTimeout(function(){
                        that.isLoading = false;
                    }, this.time || 6000);
                }
                this.$dispatch(eventStr);
            }
        }
    }
</script>