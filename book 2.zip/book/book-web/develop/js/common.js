'use strict';
// var config= require('./config.js');

//公共方法
module.exports = {
    install: function(Vue, option){
        // //初始化数据对象
        Vue.filter('init_data_filter',function(id, type){
            return option.data[type][id];
        });
        // // 初始化数据列表
        // Vue.filter('init_list_filter',function(type){
        //     return $.extend({},option.data[type]);
        // });

        function arrayToJson(arr){
            var obj = {};
            arr.forEach(function(item){
                obj[item.id] = item.name;
            });
            return obj;
        }
        // 格式化时间
        Vue.filter('datetime', function(val){
            if (!val) return val;
            var val = parseInt(val);
            var date = new Date(val),
                y = date.getFullYear(),
                m = date.getMonth() + 1,
                d = date.getDate(),
                h = date.getHours(),
                min = date.getMinutes(),
                s = date.getSeconds(),
                str = '';

            function check (value){
                return value > 9 ? value : '0' + value;
            }
            return '' + y + '-' + check(m) + '-' + check(d) + ' ' + check(h) + ':' + check(min) + ':' + check(s);
        });
        Vue.filter('date', function(val){
            if (!val) return val;
            var val = parseInt(val);
            var date = new Date(val),
                y = date.getFullYear(),
                m = date.getMonth() + 1,
                d = date.getDate(),
                str = '';

            function check (value){
                return value > 9 ? value : '0' + value;
            }
            return '' + y + '-' + check(m) + '-' + check(d);
        });
        // prototype

        // 权限
        Vue.prototype.auth_word = '暂无权限';
        Vue.prototype.auth = {
            msg_create: 'msg_create',                   // 消息创建
            msg_edit: 'msg_edit',                       // 消息编辑
            msg_search: 'msg_search',                   // 消息查询
            msg_export: 'msg_export',                   // 消息导出
            msg_delete: 'msg_delete',                   // 消息删除
            msg_result_search: 'msg_result_search',     // 消息发送结果查询
            msg_result_export: 'msg_result_export',     // 消息发送结果导出
            msg_template_create: 'msg_template_create', // 模板创建
            msg_template_edit: 'msg_template_edit',     // 模板编辑
            msg_template_search: 'msg_template_search', // 模板查询
            msg_template_delete: 'msg_template_delete'  // 模板删除
        }
        //转换日期
        Vue.prototype.dateToString = function (date){
            var myDate = new Date(date);
            var dateString = myDate.toLocaleString();
            return dateString;
        };
        //显示提示框
        Vue.prototype.showAlert = function (it, type, message){
            it.alert.show = true;
            it.alert.type = type;
            it.alert.message = message;
        };
        //ajax
        Vue.prototype.ajax = function (it, obj){
            var obj = obj;
            var that = this;
            var falg = obj.alertFalg === undefined ? true : obj.alertFlag;
            var loading = obj.loadingFlag || false;
            var errorFn = function(msg){
                that.showAlert(it, 'danger', msg);
            };
            var loadingBox = $('<div class="loading-mask"></div>');
            loading && $('body').append(loadingBox);
            
            // 清除缓存
            var v = '';
            if (obj.url.indexOf('?') < 0) {
                v = '?v=' + new Date().getTime();
            } else {
                v = '&v=' + new Date().getTime();
            }

            return $.ajax({
                type: obj.type,
                dataType: 'json',
                url: obj.url + v,
                data: obj.data,
                success: function(data){
                    if (data.error_no == 0){
                        loading && loadingBox.remove();
                        obj.success(data);
                    } else if (data.error_no == 2){
                        location.href="/index.html#/login";
                    } else {
                        loading && loadingBox.remove();
                        falg && errorFn(data.error_message);
                        if (obj.error) {
                            obj.error(data);
                        }
                    }
                    
                },
                error: function(error){
                    // loading && loadingBox.remove();
                    // var errMsg = typeof error.responseJSON === 'string' ? JSON.parse(error.responseJSON).error_message : error.responseJSON.error_message;
                    // falg && errorFn(errMsg);
                    // obj.error && obj.error(error);
                }
            })
        };
        Vue.prototype.trim = function(param){
            var obj = $.extend({},param);
            for(var i in obj){
                if(typeof obj[i] == 'string'){
                    obj[i] = $.trim(obj[i]);
                }
            }
            return obj;
        };
        // 添加checked
        Vue.prototype.addChecked = function(arr,ids){
            arr.forEach(function(i){
                ids.forEach(function(j){
                    if (i.id == j){
                        i.checked = true;
                    }
                })
            })
        };
        Vue.prototype.createUrl = function(obj,url){
            var str = '';
            for(var i in obj){
                if(obj[i]){
                    str = str + '&' + i + '=' + obj[i]; 
                }
            }
            str = str.substring(1);
            if (url) {
                if(url.indexOf('?') < 0) {
                    str = url + '?' + str;
                } else {
                    str = url + '&' + str;
                }
            }
            return str;
        };
        //点击tr 触发checkbox
        Vue.prototype.checkedTr = function(){
            $(document).off('click', 'tbody tr');
            $(document).on('click', 'tbody tr', function(){
                $(this).find('input[type=checkbox]').click();
            });
        };
        //点击checkbox 联动全选反xuan
        Vue.prototype.catchChecked = function(event){
            var thisInput = $(event.target);
            var checkBoxLength = thisInput.parents('tbody').find('input[type=checkbox]:checked').length;
            var allTrLength = thisInput.parents('tbody').find('tr:visible').length;
            if(checkBoxLength === allTrLength){
                thisInput.parents('table').find('thead input[type=checkbox]')[0].checked = true;
            }
            else{
                thisInput.parents('table').find('thead input[type=checkbox]')[0].checked = false;
            }
        };
        //全选,反选
        Vue.prototype.checkedAll = function(){
            $(document).off('click', 'table thead input[type=checkbox]');
            $(document).on('click', 'table thead input[type=checkbox]', function(event){
                //选中
                if(event.target.checked){
                    $(this).parents('table').find('tbody input[type=checkbox]:not(:checked)').each(function(){
                        $(this).click();
                    });
                }
                else{
                    $(this).parents('table').find('tbody input[type=checkbox]:checked').each(function(){
                        $(this).click();
                    });
                }
            });
        };
        //格式化时间
        Vue.prototype.regTime = function(val){
            if(!val) return;
            return val.indexOf('.') > -1 ? val.substring(0, val.indexOf('.')) : val;
        };
        // 获取时间户毫秒数
        Vue.prototype.timeStamp = function(str){
            return new Date(str).getTime();
        };
        // 格式化时间
        Vue.prototype.timeFormat = function(val){
            var date = new Date(val),
                y = date.getFullYear(),
                m = date.getMonth() + 1,
                d = date.getDate(),
                h = date.getHours(),
                min = date.getMinutes(),
                s = date.getSeconds(),
                str = '';

            function check (value){
                return value > 9 ? value : '0' + value;
            }

            return '' + y + '-' + check(m) + '-' + check(d) + ' ' + check(h) + ':' + check(min) + ':' + check(s);

        };
        Vue.prototype.usualTime = function(val){
            var d = val / 1000 / 60 / 60 / 24,
                dr = Math.floor(d),
                dw = dr > 0 ? dr + '天' : '',
                h = val / 1000 / 60 / 60 - (24 * dr),
                hr = Math.floor(h),
                hw = hr > 0 ? hr + '小时' : '',
                m = val / 1000 /60 - (24 * 60 * dr) - (60 * hr),
                mr = Math.floor(m),
                mw = mr > 0 ? mr + '分' : '',
                s = val / 1000 - (24 * 60 * 60 * dr) - (60 * 60 * hr) - (60 * mr),
                sr = Math.ceil(s),
                sw = sr > 0 ? sr + '秒' : '';
            return dw + hw + mw + sw; 

        };
        // 校验邮箱
        Vue.prototype.checkEmailFormat = function(str) {
            var reg =  /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return reg.test(str);
        };
        // 校验手机
        Vue.prototype.checkMobileFormat = function(num) {
            var reg = /^1[3|4|5|7|8]\d{9}$/;
            return reg.test(num);
        };
        // 校验身份证
        Vue.prototype.checkIdCardFormat = function(num) {
            var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
            return reg.test(num);
        };
        // 校验护照
        Vue.prototype.checkPassportFormat = function(num) {
            var reg = /^1[45][0-9]{7}|G[0-9]{8}|P[0-9]{7}|S[0-9]{7,8}|D[0-9]+$/;
            return reg.test(num);
        };
        // 校验军官证
        Vue.prototype.checkSoldierFormat = function(num) {
            var reg = /^[a-zA-Z0-9]{7,21}$/;
            return reg.test(num);
        };
        // 校验台胞证
        Vue.prototype.checkTaiwanFormat = function(num) {
            var reg = /^\d{10}\(B\)$/;
            return reg.test(num);
        };
        // 校验QQ号
        Vue.prototype.checkQqFormat = function(num) {
            var reg = /^[1-9]\d{4,9}$/;
            return reg.test(num);
        };
        // 校验数字
        Vue.prototype.isNumber = function(num) {
            var reg = /^\d+$/;
            return reg.test(num);
        };
        // 校验Ip
        Vue.prototype.isIp = function(num) {
            var reg = /^([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])$/;
            return reg.test(num);
        };
        // 校验中文
        Vue.prototype.isZh = function(num) {
            var reg = /^[\u4e00-\u9fa5]*$/;
            return reg.test(num);
        };
        // 查看大图片
        Vue.prototype.showPic = function(src){
            var tpl = '<div class="show-pic"> \
                        <div class="show-pic-content"></div> \
                        <div class="show-pic-bg"></div> \
                        <i class="show-pic-close icon icon-close-20"></i> \
                    </div>';
            var $tpl = $(tpl),
                $content = $tpl.find('.show-pic-content'),
                $close = $tpl.find('.show-pic-close'),
                resizeHander = '';    // 监听窗口变化

            $close.on('click', function(){
                $tpl.removeClass('ps');
                setTimeout(function(){
                    $tpl.remove();
                },300);
                $(window).off('resize', resizeHander);
            });

            // 窗口大小变更时监听图片显示
            $(window).on('resize', resizeHander = function(){
                loadback();
            });

            var img = document.createElement('img');
            img.src = src;
            img.onload = function(){
                loadback();
            };

            function loadback(){
                var img_w = img.width,
                    img_h = img.height,
                    c_w = $content.width(),
                    c_h = $content.height();
                if (img_w/img_h > c_w/c_h){
                    $content.css({
                        'background-size': '100% auto',
                        'background-image': 'url(' + src + ')'
                    });
                } else {
                    $content.css({
                        'background-size': 'auto 100%',
                        'background-image': 'url(' + src + ')'
                    });
                }
            }

            $('body').append($tpl);
            $tpl.addClass('ps');
        };

        // 展开收起
        Vue.prototype.toggle = function(){
            var dir = 
            $('.bs-item-dir').on('click', function(){
                $(this).toggleClass('close');
                $(this).parents('.bs-item-title').toggleClass('no-border');
                $(this).parents('.bs-item').find('.bs-item-body').toggle();
            })
        };

        // 图片上传
        Vue.prototype.upload = function(file, sign){
            var that = this;
            var url =  '/Api/resource/upload';
            var xhr = new XMLHttpRequest();
            var fd = new FormData();
            var maxFileSize = 1024*1024*5;  // 5M

            if(file.size >= maxFileSize ){  


                that.errorTips='文件大小超限';
                that.showErrorTips = true;

                // 显示文件超限错误提示
                $('#uploader-preview-'+that.id).html('<span class="toolagre">文件大小超限</span>');
                that.pid = '';

                that.showUploader = true; //是否显示上传框
                that.showReUploader = true; //是否显示重新上传按钮
                that.showUploaderPreview = false; //是否显示预览


            }else{


                // 显示文件超限错误提示
                $('#uploader-preview-'+that.id).html('<span class="toolagre">正在上传，请稍后</span>');
                that.pid = '';


                that.errorTips='正在上传，请稍后';
                that.showErrorTips = true;

                xhr.open("POST", url, true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        var data = $.parseJSON(xhr.responseText);

                        if(data.ErrNo == 0){

                            var json = data.Result[0];
                            that.pid = json.id;

                            that.showErrorTips = false; //关闭上传提示

                            that.showPreview(file, 'uploader-preview-'+ that.id);


                        }else{


                            that.errorTips='上传失败，请重试';
                            that.showErrorTips = true;

                            that.showUploader = true; //是否显示上传框
                            that.showReUploader = true; //是否显示重新上传按钮
                            that.showUploaderPreview = false; //是否显示预览

                        }

                    }
                };
                fd.append("upload_file", file);
                xhr.send(fd);


            }
        };

        // 二次确认
        Vue.prototype.tipSure = function(opt){
            
            var tpl = '<div class="tip-sure">\
                        <div class="tip-sure-content">\
                            <i class="tsc-close icon icon-close-20 tsc-cancel"></i>\
                            <h3 class="tsc-title">提示</h3>\
                            <div class="tsc-info">确定要这么做么？</div>\
                            <div class="tsc-footer">\
                                <button class="btn btn-sm tsc-cancel">取消</button>\
                                <button class="btn btn-primary btn-sm tsc-sure">确定</button>\
                            </div>\
                        </div>\
                    </div>';
            var defaults = {
                sure: function(){},
                rem: function($tpl){
                    $tpl.removeClass('ps');
                    setTimeout(function(){
                        $tpl.remove();
                    },300);
                },
                title: '提示',
                info: '确定要进行该操作吗？'
            };
            var option = $.extend({},defaults,opt),
                $tpl = $(tpl),
                $title = $tpl.find('.tsc-title'),
                $info = $tpl.find('.tsc-info'),
                $sure = $tpl.find('.tsc-sure'),
                $cancel = $tpl.find('.tsc-cancel');

            $title.text(option.title);
            $info.text(option.info);

            $cancel.on('click', function(){
                option.rem($tpl);
            });

            $sure.on('click', function(){
                option.rem($tpl);
                option.sure.call(option.scope);
            });

            $('body').append($tpl);
            $tpl.addClass('ps');
        };

        /*
         * 压缩并上传
         * opt 接收的参数
         * rel 返回的结果
         **/ 
        Vue.prototype.minUpload = function(opt, rel){
            var that = this;
                var file = opt.file;
                $('body').append($('<canvas id="_canvas" style="display: none;"></canvas>'));
                var canvas=document.getElementById('_canvas');
                var ctx=canvas.getContext('2d');

                // file.onchange = function(){
                    var fileData = file.files[0];
                    console.log(fileData)
                    var url = URL.createObjectURL(fileData);
                    var img = new Image();
                    img.src = url;
                    img.onload = function(){
                        ctx.drawImage(img, 0, 0, $(img).width(), $(img).height());
                        var base64 = canvas.toDataURL(fileData.type, 0.5);
                        
                        var blob = dataURLtoBlob(base64);
                        blob.name = fileData.name;
                        blob.lastModified = fileData.lastModified;
                        blob.lastModifiedDate = fileData.lastModifiedDate;
                        // 转换为formData对像
                        var fd = new FormData();
                        fd.append("image", blob, fileData.name);

                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', '/file/7292405841480305862790', true);
                        xhr.send(fd);
                        xhr.onreadystatechange = function(){
                            if(xhr.readyState==4 && xhr.status==200){
                                console.log(xhr.responseText);
                                // testImg.src = base64;
                                $(canvas).remove();
                            }
                        }
                    }
                     
                // }

                function dataURLtoBlob(dataurl) {
                    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
                        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
                    while(n--){
                        u8arr[n] = bstr.charCodeAt(n);
                    }
                    return new Blob([u8arr], {type:mime});
                }
        };
    }
}
