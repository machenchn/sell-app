var gulp = require('gulp');
    baseWebpack = require('webpack'),
    webpack = require('webpack-stream'),
    usemin = require('gulp-usemin'),
    gutil = require('gulp-util'),//gulp-util工具包
    uglify = require('gulp-uglify'),
    filter = require('gulp-filter'),
    rename = require("gulp-rename"),
    webserver = require("gulp-webserver"),
    rev = require('gulp-rev'),
    replace = require('gulp-replace'), //文件替换
    revCollector = require('gulp-rev-collector'),
    // sass = require('gulp-sass'),
    changed = require('gulp-changed'),
    connect = require('gulp-connect'),
    // sassLint = require('gulp-sass-lint'),
    cssmin = require('gulp-cssmin'),
    cleanCSS = require('gulp-clean-css'),
    concatCss = require('gulp-concat-css'),
    autoprefixer = require('gulp-autoprefixer'),
    nocache = require('gulp-nocache'),
    babel = require('babel-loader'),
    polyfill = require('babel-polyfill'),
    Q = require('q'),
    url = require('url'),
    path = require('path'),
    moment = require('moment'),
    gulpSequence = require('gulp-sequence'),//任务队列
    named = require('vinyl-named'),
    through = require('through2'),
    scp = require('gulp-scp2');

var childProcess = require('child_process'),
    exec = Q.nbind(childProcess.exec);

var ExtractTextPlugin = require("extract-text-webpack-plugin");


// 开发路径
var developPath = {
    js: './develop/**/*.js',
    css: './develop/css/**/*.css',
    img: './develop/img/**/*.*',
    lib: './develop/lib/**/*.*',
    // sass: './develop/sass/**/*.s+(a|c)ss',
    // index: './develop/index.html',
    index: './develop/*.html',
    main: './develop'
};

// 编译路径
var buildPath = {
    js: './build/js',
    css: './build/css',
    img: './build/img',
    lib: './build/lib',
    main: './build'
};

// 发布路径，压缩版
var distPath = {
    js: './dist/js',
    css: './dist/css',
    img: './dist/img',
    lib: './dist/lib',
    main: './dist'
};




gulp.task('init' , function(){

    console.log( now(), gutil.colors.yellow('gulp init begin') );

    // 删除rev目录 && 删除 build 目录

    exec('rm -rf ' + buildPath.main);
    console.log( now(), gutil.colors.yellow('rm -rf  '  + buildPath.main ) );

    exec('rm -rf ' + distPath.main);
    console.log( now(), gutil.colors.yellow('rm -rf  '  + distPath.main ) );

    exec('rm -rf ./rev' );
    console.log( now(), gutil.colors.yellow('rm -rf  ./rev' ) );
    console.log( now(), gutil.colors.yellow('gulp init success') );

});






// 默认编译
// 开发过程中打开监控
gulp.task('default', ['webpack','begin'], function(){
    console.log('默认task执行完毕，进行了develop目录的构建. ');
    console.log('如需构建dist目录并压缩代码并MD5化，，可执行 >gulp build #任务 ');
});
// 开发过程中打开监控
gulp.task('dev', ['webpack','begin','webpack:watch','begin:watch','webserver']);
gulp.task('develop', ['webpack','begin','webpack:watch','begin:watch']);


var commonJsPlugin  = new baseWebpack.optimize.CommonsChunkPlugin({
    name:'common',
    filename:'common.js',
    // chunks:['','',''],
    minChunks:3
});
var commonCssPlugin = new ExtractTextPlugin('../../'+buildPath.css+'/app.css');
// var commonPlugin = new baseWebpack.optimize.CommonsChunkPlugin({
// 	name:'common',
// 	filename:'common-lib.js',
// 	// chunks:['','',''],
// 	minChunks:1
// });

gulp.task('webpack', function() {
    return gulp.src(['develop/config.js','develop/plugin.js','develop/main.js'])
        .pipe(named())
        .pipe(webpack({
            // watch: true,
            // devtool: 'source-map'
            plugins: [commonJsPlugin,commonCssPlugin ],
            module:{
                loaders:[
                    { test: /\.vue$/, loader:'vue' },
                    { test: /\.css$/, loader: 'style-loader!css-loader' },
                    { test: /\.js$/, exclude: /node_modules/, loader:'babel' },
                    { test: /\.(png|jpg|gif)$/, loader: 'file?name=[name].[ext]?[hash]' }
                    // { test: /\.scss$/, loaders: ['style', 'css', 'sass'] }
                ]
            },
            babel: {
                presets: ['es2015'],
                plugins: ['transform-runtime']
            },
            vue:{
                loaders:{
                    css: ExtractTextPlugin.extract("css"),
                    // you can also include <style lang="sass"> or other langauges
                    // sass: ExtractTextPlugin.extract("css!sass")
                }
            }
        }))
        .pipe(gulp.dest(buildPath.js));
});

gulp.task('webpack:watch', function() {
    // const f = filter(['*', '!develop/img'], {restore: true, passthrough: false});
    // gulp.watch( f , ['webpack']);
    // gulp.watch(['./develop/**/*.*','!develop/img'], ['webpack']);
    gulp.watch( './develop/**/*.*' , ['webpack']);
});


gulp.task('webserver', function() {
    gulp.src('./')
        .pipe(webserver({
            port: 8081,
            host: '0.0.0.0',
            directoryListing: {
                enable:true,
                path:'./'
            },
            /*livereload: true,*/
            //open: 'index.html',
            /*https:{ key: './ssl/ssl.key', cert: './ssl/ssl.crt' },*/
            proxies: [
            
                // { source: '/api', options: {headers: {'HOST': myConfig.proxyserverHeader3 }} , target: myConfig.proxyServerDomain3},
                // { source: '/api', target: myConfig.proxyServerDomain4 + '/api'},
                { source: '/api' ,options: {headers: {'HOST': 'book.ksyun.com' }} , target: 'http://127.0.0.1:8082' + '/api'},
                // { source: '/api' ,options: {headers: {'HOST': 'book.ksyun.com' }} , target: 'http://192.168.1.103:8081' + '/api'},
                { source: '/file' ,options: {headers: {'HOST': 'captcha2.ksyun.com' }} , target: 'http://10.111.17.83' + '/file'},
                // { source: '/bossv2', target: myConfig.proxyServerDomain5 + '/bossv2'}
            ]
        }));
});


// 初始化启动
gulp.task('begin', function(){

    //编译sass
    // gulp.src(developPath.sass)
    //     .pipe(changed(buildPath.css))
    //     .pipe(sass().on('error', sass.logError))
    //     .pipe(concatCss('style.css'))
    //     .pipe(autoprefixer())
    //     .pipe(gulp.dest(buildPath.css));

    //合并CSS文件
    gulp.src(developPath.css)
        .pipe(concatCss('style.css'))
        .pipe(gulp.dest(buildPath.css));

    //移动lib目录
    gulp.src(developPath.lib)
        .pipe(gulp.dest(buildPath.lib));

    //移动img图片文件从
    gulp.src(developPath.img)
        .pipe(gulp.dest(buildPath.img));

    //移动 index.html 入口文件
    gulp.src(developPath.index)
        .pipe(gulp.dest(buildPath.main))
        .pipe(gulp.dest('./'));

});
// 监控开发目录
gulp.task('begin:watch', function(){
    gulp.watch('./develop/**/*.*',['begin']);
});



gulp.task('uglify-lib', function(){
    gulp.src('./develop/lib/wangEditor/js/wangEditor.js')
        .pipe(rename({ suffix: '.min' }))
        .pipe(uglify())
        .pipe(gulp.dest('./develop/lib/wangEditor/js'));
});
gulp.task('cssmin-lib', function(){
    gulp.src('./develop/lib/wangEditor/css/wangEditor.css')
        .pipe(rename({ suffix: '.min' }))
        .pipe(cssmin())
        .pipe(gulp.dest('./develop/lib/wangEditor/css'));
});





// var d = Q.defer();
// d.resolve(revjs);
// return d.promise;

gulp.task('revPretask', function(){


    console.log(  now(), gutil.colors.yellow(' 执行 revPretask - MD5 化静态资源开始')  );


    gulp.src(buildPath.js+'/**/*.js')
        .pipe(uglify())
        .pipe(rev())
        .pipe(gulp.dest(distPath.js))
        .pipe(rev.manifest())
        .pipe(gulp.dest('rev/js'));


    console.log(  now(), gutil.colors.yellow(' 执行 revPretask - MD5-》JS 资源 完成')  );


    gulp.src(buildPath.css+'/**/*.css')
        .pipe(cleanCSS())
        .pipe(rev())
        .pipe(gulp.dest(distPath.css))
        .pipe(rev.manifest())
        .pipe(gulp.dest('rev/css'));

    console.log(  now(), gutil.colors.yellow(' 执行 revPretask - MD5->CSS 资源 完成')  );

    gulp.src(buildPath.lib+'/**/*.*')
        .pipe(gulp.dest(distPath.lib));

    console.log(  now(), gutil.colors.yellow(' 移动 IMG 图片文件至 dist目录完成 ，图片资源 无需MD5化处理 ')   ); 


        // 无需处理图片文件,z 直接移动即可
    gulp.src(buildPath.img+'/**/*.*')
        .pipe(gulp.dest(distPath.img));


    console.log(  now(), gutil.colors.yellow(' 无需处理图片文件,z 直接移动即可 ')   ); 



});



// 上发布前的压缩
gulp.task('revJSImg', function(){

    console.log(   now(), gutil.colors.green(' 执行 revJSImg  根据生成的 rev-manifest.json 文件替换 js 文件名称  ') );


    setTimeout(function(){

        gulp.src(['rev/**/*.json', distPath.js+'/**/*.js'])
            .pipe(revCollector({
                replaceReved: true,
                dirReplacements: {
                    'build/img/': 'dist/img/'
                }
            }))
            .pipe( gulp.dest(distPath.js) );

        console.log(   now(), gutil.colors.yellow(' 执行 revJSImg   js文件路径替换完成  ') );

    },2000);

});//MD5


gulp.task('rev' , function(){

    console.log(  now(), gutil.colors.yellow('执行 rev ') );


    setTimeout(function(){


        console.log(  now(),  gutil.colors.yellow('执行 rev 根据rev-manifest.js 替换 : ' ,  buildPath.main +'/index.html  内的文件路径 '  ) );


        gulp.src(['rev/**/*.json', buildPath.main + '/index.html'])
            .pipe(revCollector({
                // replaceReved: true,
                dirReplacements: {

                    'build/js/': 'dist/js/',
                    'build/css/': 'dist/css/',
                    'build/img/': 'dist/img/',
                    'build/lib/': 'dist/lib/'

                }
            }))
            .pipe( gulp.dest( buildPath.main ) )
            .pipe( gulp.dest('./') );



        console.log(   now(), gutil.colors.yellow(' 执行 rev 替换 index.html 文件内的 静态资源路径   完成  ') );


    },10000);


});//MD5





gulp.task('end' , function(){


    setTimeout(function(){

        console.log(  now(), gutil.colors.red('执行 end ') );




        console.log(  now(), gutil.colors.yellow( '将 dist目录内 CSS 文件 build/ 替换为 dist/  目录 ')  );

        gulp.src( distPath.css +'/**/*.css' )
            .pipe( replace('build/img', 'dist/img') )
            .pipe( gulp.dest( distPath.css  ) );


        console.log( now(), gutil.colors.yellow( '将 dist目录内 CSS 文件 build/ 替换为 dist/  目录 完成')  );




        console.log(  now(), gutil.colors.yellow( '将 dist目录内 Javascript 文件 build/ 替换为 dist/  目录 ')  );

        gulp.src( distPath.js +'/**/*.js' )
            .pipe( replace('build/', 'dist/') )
            .pipe( gulp.dest( distPath.js  ) );

        console.log( now(), gutil.colors.yellow( '将 dist目录内 Javascript 文件 build/ 替换为 dist/  目录 完成')  );




        console.log('将 入口文件 build/index.html 文件中的 build/ 目录替换为 dist/ 目录 ');

        gulp.src( buildPath.main +'/*.html' )
            .pipe( replace('build/', 'dist/') )
            .pipe( gulp.dest( distPath.main  ) )
            .pipe( gulp.dest( './'  ) );

        console.log('将 入口文件 build/index.html 文件中的 build/ 目录替换为 dist/ 目录 ');


        console.log( now(), gutil.colors.yellow(' 构建dist目录,执行静资源压缩以及md5化完成. ')  );

        console.log( now(), gutil.colors.yellow(' 项目构建完成，可发布！到生成环境 ') );


    },20000);

});//end




gulp.task('build', gulpSequence( 'init', 'default', 'revPretask', 'revJSImg', 'rev' ,'end' ) );





// 一台虚拟机
// 10.146.16.144
// root KSC123
gulp.task('deploy', ['build'], function(){
    var t = new Date();
    var year = t.getFullYear();
    var month = (t.getMonth() + 1) < 10 ? '0'+(t.getMonth() + 1) : (t.getMonth() + 1);
    var day = t.getDate();
    var suffix = t.getHours()+''+t.getMinutes()+''+t.getSeconds();
    var name = 'dist_'+year+month+day+'_'+suffix+'.tar.gz';

    return exec('cd dist && tar -zcf '+name+' ./*')
        .then(function(){
            return exec('scp dist/'+name+' root@10.146.16.144:/tmp')
        })
        .then(function() {
            return exec('ssh root@10.146.16.144 "cp /tmp/'+name+' /home/www/ksc-base-framework"')
        })
        // .then(function() {
        //     return exec('ssh root@10.146.16.144 "su www -c \'cd /data/projects/node && ./ksyun.sh\'"')
        // })
        .catch(function(e) {
            console.log('error', e);
        });

});

function now(timestamp){
    if(timestamp === undefined){
        timestamp = new Date().getTime();
    }else if((''+timestamp).length === 10){
        timestamp = parseInt(timestamp+'000');
    }
    return moment( timestamp ).format('YYYY/MM/DD HH:mm:ss"SSS') 
}




