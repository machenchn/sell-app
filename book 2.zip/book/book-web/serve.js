var http = require('http');
var httpProxy = require('http-proxy');
var url = require('url');
var fs = require('fs');
var path = require('path');
var log4js = require('log4js');

var proxy = httpProxy.createProxyServer({});
var logger = log4js.getLogger();
logger.setLevel('INFO');
var config={
        "contentType":{
            "css": "text/css",
            "gif": "image/gif",
            "html": "text/html",
            "ico": "image/x-icon",
            "jpeg": "image/jpeg",
            "jpg": "image/jpeg",
            "js": "text/javascript",
            "json": "application/json",
            "pdf": "application/pdf",
            "png": "image/png",
            "svg": "image/svg+xml",
            "swf": "application/x-shockwave-flash",
            "tiff": "image/tiff",
            "txt": "text/plain",
            "wav": "audio/x-wav",
            "wma": "audio/x-ms-wma",
            "wmv": "video/x-ms-wmv",
            "xml": "text/xml"
        },
        "backendHost":"10.146.16.145:80"
    };
var mime = config.contentType;

var staticPath = ".";

var app = function(req, res) {
    var urlPath = url.parse(req.url).pathname;
    var realPath = staticPath + urlPath;
    var ext = path.extname(realPath);
    ext = ext ? ext.slice(1) : 'unknown';

    if(ext === 'unknown'){
        logger.info(urlPath+ ' request from '+ config.backendHost);
        proxy.web(req, res, { target: "http://"+config.backendHost });
    }else{
        fs.exists(realPath, function (exists) {
            if (!exists) {
                logger.warn(realPath+' request from local,but not found ');
                res.writeHead(404, {'Content-Type': 'text/plain'});
                res.write("This request URL " + urlPath + " was not found on this server.");
                res.end();
            } else {
                fs.readFile(realPath, "binary", function(err, file) {
                    var contentType = mime[ext] || "text/plain";
                    if (err) {
                        logger.error(realPath+' request from local error ');
                        res.writeHead(500, {'Content-Type': 'text/plain'});
                        res.end(err);
                    } else {
                        logger.info(realPath+' request from local success ');
                        res.writeHead(200, {'Content-Type': contentType});
                        res.write(file, "binary");
                        res.end();
                    }
                });
            }
        });
    }
};

http.createServer(app).listen(80,function(){
    logger.info("http listening on port 0.0.0.0:80")
});
