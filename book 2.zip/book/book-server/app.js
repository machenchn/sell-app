var express = require('express'),
	bodyParser = require('body-parser'),
	// cookieParser = require('cookie-parser'),
	app = express(),
	com = require('./lib/controller/comController'),
	tool = require('./lib/common/tool'),
	conf = require('./lib/common/conf'),
	user = require('./lib/controller/userController'),
	book = require('./lib/controller/bookController'),
	borrow = require('./lib/controller/borrowController')
	history = require('./lib/controller/historyController');


app.use(bodyParser.urlencoded({extend:true}));
app.use(bodyParser.json());

// 连接mongodb
var mongoose = require("mongoose");	
mongoose.connect('mongodb://localhost/book');

// 全局设置
app.all('*', function(req, res, next){
	res.setHeader("Content-Type", "application/json");
	next();
});

// 路由
// public
app.get('/api/init',com.init);
app.get('/api/init_setting',com.initSetting);

// 用户相关
app.post('/api/user/login',user.login);
app.post('/api/user/logout',user.logout);
app.post('/api/user/update_password',user.updatePassword);
app.post('/api/user/list',user.lists);
app.post('/api/user/list_all',user.listsAll);
app.post('/api/user/count',user.count);
app.get('/api/user/detail/:id',user.detail);
app.post('/api/user/add',user.add);
app.post('/api/user/update',user.update);
app.post('/api/user/remove',user.remove);
app.post('/api/user/reset',user.resetPassword);
app.get('/api/user/exports',user.exports);

// 书相关
app.post('/api/book/list',book.lists);
app.post('/api/book/count',book.count);
app.get('/api/book/detail/:id',book.detail);
app.post('/api/book/add',book.add);
app.post('/api/book/update',book.update);
app.post('/api/book/remove',book.remove);
app.post('/api/book/borrow',book.borrow);
app.get('/api/book/exports',book.exports);

// 历史记录
app.post('/api/history/list',history.lists);
app.get('/api/history/detail/:id',history.detail);
app.get('/api/history/ranking',history.ranking);
app.get('/api/history/dresser',history.dresser);
app.get('/api/history/exports',history.exports);

// 借阅中的书
app.post('/api/borrow/list',borrow.lists);
app.post('/api/borrow/update/',borrow.update);
app.post('/api/borrow/remove/',borrow.remove);
app.get('/api/borrow/exports',borrow.exports);

// 启动服务
var server = app.listen(8082, function () {
	var host = server.address().address;
	var port = server.address().port;
	console.log("应用实例，访问地址为 http://%s:%s", host, port)
});